

/* First created by JCasGen Thu Jan 21 17:12:36 CET 2021 */
package lu.svv.saa.maana.type;

import org.apache.uima.jcas.JCas; 
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;

import org.apache.uima.jcas.tcas.Annotation;


/** 
 * Updated by JCasGen Thu Jan 21 17:12:38 CET 2021
 * XML source: /Users/sallam.abualhaija/eclipse-workspace/lu.svv.saa.maana/src/main/resources/desc/type/AmbiguousPhrase.xml
 * @generated */
public class AmbiguousPhrase extends Annotation {
  /** @generated
   * @ordered 
   */
  @SuppressWarnings ("hiding")
  public final static int typeIndexID = JCasRegistry.register(AmbiguousPhrase.class);
  /** @generated
   * @ordered 
   */
  @SuppressWarnings ("hiding")
  public final static int type = typeIndexID;
  /** @generated
   * @return index of the type  
   */
  @Override
  public              int getTypeIndexID() {return typeIndexID;}
 
  /** Never called.  Disable default constructor
   * @generated */
  protected AmbiguousPhrase() {/* intentionally empty block */}
    
  /** Internal - constructor used by generator 
   * @generated
   * @param addr low level Feature Structure reference
   * @param type the type of this Feature Structure 
   */
  public AmbiguousPhrase(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }
  
  /** @generated
   * @param jcas JCas to which this Feature Structure belongs 
   */
  public AmbiguousPhrase(JCas jcas) {
    super(jcas);
    readObject();   
  } 

  /** @generated
   * @param jcas JCas to which this Feature Structure belongs
   * @param begin offset to the begin spot in the SofA
   * @param end offset to the end spot in the SofA 
  */  
  public AmbiguousPhrase(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }   

  /** 
   * <!-- begin-user-doc -->
   * Write your own initialization here
   * <!-- end-user-doc -->
   *
   * @generated modifiable 
   */
  private void readObject() {/*default - does nothing empty block */}
     
 
    
  //*--------------*
  //* Feature: id

  /** getter for id - gets Ambiguity's ID
   * @generated
   * @return value of the feature 
   */
  public int getId() {
    if (AmbiguousPhrase_Type.featOkTst && ((AmbiguousPhrase_Type)jcasType).casFeat_id == null)
      jcasType.jcas.throwFeatMissing("id", "lu.svv.saa.maana.type.AmbiguousPhrase");
    return jcasType.ll_cas.ll_getIntValue(addr, ((AmbiguousPhrase_Type)jcasType).casFeatCode_id);}
    
  /** setter for id - sets Ambiguity's ID 
   * @generated
   * @param v value to set into the feature 
   */
  public void setId(int v) {
    if (AmbiguousPhrase_Type.featOkTst && ((AmbiguousPhrase_Type)jcasType).casFeat_id == null)
      jcasType.jcas.throwFeatMissing("id", "lu.svv.saa.maana.type.AmbiguousPhrase");
    jcasType.ll_cas.ll_setIntValue(addr, ((AmbiguousPhrase_Type)jcasType).casFeatCode_id, v);}    
   
    
  //*--------------*
  //* Feature: CCid

  /** getter for CCid - gets Coordination's ID
   * @generated
   * @return value of the feature 
   */
  public int getCCid() {
    if (AmbiguousPhrase_Type.featOkTst && ((AmbiguousPhrase_Type)jcasType).casFeat_CCid == null)
      jcasType.jcas.throwFeatMissing("CCid", "lu.svv.saa.maana.type.AmbiguousPhrase");
    return jcasType.ll_cas.ll_getIntValue(addr, ((AmbiguousPhrase_Type)jcasType).casFeatCode_CCid);}
    
  /** setter for CCid - sets Coordination's ID 
   * @generated
   * @param v value to set into the feature 
   */
  public void setCCid(int v) {
    if (AmbiguousPhrase_Type.featOkTst && ((AmbiguousPhrase_Type)jcasType).casFeat_CCid == null)
      jcasType.jcas.throwFeatMissing("CCid", "lu.svv.saa.maana.type.AmbiguousPhrase");
    jcasType.ll_cas.ll_setIntValue(addr, ((AmbiguousPhrase_Type)jcasType).casFeatCode_CCid, v);}    
   
    
  //*--------------*
  //* Feature: Mid

  /** getter for Mid - gets Modifier's ID
   * @generated
   * @return value of the feature 
   */
  public int getMid() {
    if (AmbiguousPhrase_Type.featOkTst && ((AmbiguousPhrase_Type)jcasType).casFeat_Mid == null)
      jcasType.jcas.throwFeatMissing("Mid", "lu.svv.saa.maana.type.AmbiguousPhrase");
    return jcasType.ll_cas.ll_getIntValue(addr, ((AmbiguousPhrase_Type)jcasType).casFeatCode_Mid);}
    
  /** setter for Mid - sets Modifier's ID 
   * @generated
   * @param v value to set into the feature 
   */
  public void setMid(int v) {
    if (AmbiguousPhrase_Type.featOkTst && ((AmbiguousPhrase_Type)jcasType).casFeat_Mid == null)
      jcasType.jcas.throwFeatMissing("Mid", "lu.svv.saa.maana.type.AmbiguousPhrase");
    jcasType.ll_cas.ll_setIntValue(addr, ((AmbiguousPhrase_Type)jcasType).casFeatCode_Mid, v);}    
   
    
  //*--------------*
  //* Feature: N2id

  /** getter for N2id - gets N2's ID
   * @generated
   * @return value of the feature 
   */
  public int getN2id() {
    if (AmbiguousPhrase_Type.featOkTst && ((AmbiguousPhrase_Type)jcasType).casFeat_N2id == null)
      jcasType.jcas.throwFeatMissing("N2id", "lu.svv.saa.maana.type.AmbiguousPhrase");
    return jcasType.ll_cas.ll_getIntValue(addr, ((AmbiguousPhrase_Type)jcasType).casFeatCode_N2id);}
    
  /** setter for N2id - sets N2's ID 
   * @generated
   * @param v value to set into the feature 
   */
  public void setN2id(int v) {
    if (AmbiguousPhrase_Type.featOkTst && ((AmbiguousPhrase_Type)jcasType).casFeat_N2id == null)
      jcasType.jcas.throwFeatMissing("N2id", "lu.svv.saa.maana.type.AmbiguousPhrase");
    jcasType.ll_cas.ll_setIntValue(addr, ((AmbiguousPhrase_Type)jcasType).casFeatCode_N2id, v);}    
   
    
  //*--------------*
  //* Feature: text

  /** getter for text - gets The Ambiguous Phrase's text
   * @generated
   * @return value of the feature 
   */
  public String getText() {
    if (AmbiguousPhrase_Type.featOkTst && ((AmbiguousPhrase_Type)jcasType).casFeat_text == null)
      jcasType.jcas.throwFeatMissing("text", "lu.svv.saa.maana.type.AmbiguousPhrase");
    return jcasType.ll_cas.ll_getStringValue(addr, ((AmbiguousPhrase_Type)jcasType).casFeatCode_text);}
    
  /** setter for text - sets The Ambiguous Phrase's text 
   * @generated
   * @param v value to set into the feature 
   */
  public void setText(String v) {
    if (AmbiguousPhrase_Type.featOkTst && ((AmbiguousPhrase_Type)jcasType).casFeat_text == null)
      jcasType.jcas.throwFeatMissing("text", "lu.svv.saa.maana.type.AmbiguousPhrase");
    jcasType.ll_cas.ll_setStringValue(addr, ((AmbiguousPhrase_Type)jcasType).casFeatCode_text, v);}    
   
    
  //*--------------*
  //* Feature: sentence

  /** getter for sentence - gets The Ambiguous sentence's text
   * @generated
   * @return value of the feature 
   */
  public String getSentence() {
    if (AmbiguousPhrase_Type.featOkTst && ((AmbiguousPhrase_Type)jcasType).casFeat_sentence == null)
      jcasType.jcas.throwFeatMissing("sentence", "lu.svv.saa.maana.type.AmbiguousPhrase");
    return jcasType.ll_cas.ll_getStringValue(addr, ((AmbiguousPhrase_Type)jcasType).casFeatCode_sentence);}
    
  /** setter for sentence - sets The Ambiguous sentence's text 
   * @generated
   * @param v value to set into the feature 
   */
  public void setSentence(String v) {
    if (AmbiguousPhrase_Type.featOkTst && ((AmbiguousPhrase_Type)jcasType).casFeat_sentence == null)
      jcasType.jcas.throwFeatMissing("sentence", "lu.svv.saa.maana.type.AmbiguousPhrase");
    jcasType.ll_cas.ll_setStringValue(addr, ((AmbiguousPhrase_Type)jcasType).casFeatCode_sentence, v);}    
   
    
  //*--------------*
  //* Feature: pattern

  /** getter for pattern - gets The Ambiguous Phrase's pattern
   * @generated
   * @return value of the feature 
   */
  public String getPattern() {
    if (AmbiguousPhrase_Type.featOkTst && ((AmbiguousPhrase_Type)jcasType).casFeat_pattern == null)
      jcasType.jcas.throwFeatMissing("pattern", "lu.svv.saa.maana.type.AmbiguousPhrase");
    return jcasType.ll_cas.ll_getStringValue(addr, ((AmbiguousPhrase_Type)jcasType).casFeatCode_pattern);}
    
  /** setter for pattern - sets The Ambiguous Phrase's pattern 
   * @generated
   * @param v value to set into the feature 
   */
  public void setPattern(String v) {
    if (AmbiguousPhrase_Type.featOkTst && ((AmbiguousPhrase_Type)jcasType).casFeat_pattern == null)
      jcasType.jcas.throwFeatMissing("pattern", "lu.svv.saa.maana.type.AmbiguousPhrase");
    jcasType.ll_cas.ll_setStringValue(addr, ((AmbiguousPhrase_Type)jcasType).casFeatCode_pattern, v);}    
   
    
  //*--------------*
  //* Feature: textBegin

  /** getter for textBegin - gets The Ambiguous Phrase's text beginning if it has any
   * @generated
   * @return value of the feature 
   */
  public int getTextBegin() {
    if (AmbiguousPhrase_Type.featOkTst && ((AmbiguousPhrase_Type)jcasType).casFeat_textBegin == null)
      jcasType.jcas.throwFeatMissing("textBegin", "lu.svv.saa.maana.type.AmbiguousPhrase");
    return jcasType.ll_cas.ll_getIntValue(addr, ((AmbiguousPhrase_Type)jcasType).casFeatCode_textBegin);}
    
  /** setter for textBegin - sets The Ambiguous Phrase's text beginning if it has any 
   * @generated
   * @param v value to set into the feature 
   */
  public void setTextBegin(int v) {
    if (AmbiguousPhrase_Type.featOkTst && ((AmbiguousPhrase_Type)jcasType).casFeat_textBegin == null)
      jcasType.jcas.throwFeatMissing("textBegin", "lu.svv.saa.maana.type.AmbiguousPhrase");
    jcasType.ll_cas.ll_setIntValue(addr, ((AmbiguousPhrase_Type)jcasType).casFeatCode_textBegin, v);}    
   
    
  //*--------------*
  //* Feature: textEnd

  /** getter for textEnd - gets The Ambiguous Phrase's text end if it has any
   * @generated
   * @return value of the feature 
   */
  public int getTextEnd() {
    if (AmbiguousPhrase_Type.featOkTst && ((AmbiguousPhrase_Type)jcasType).casFeat_textEnd == null)
      jcasType.jcas.throwFeatMissing("textEnd", "lu.svv.saa.maana.type.AmbiguousPhrase");
    return jcasType.ll_cas.ll_getIntValue(addr, ((AmbiguousPhrase_Type)jcasType).casFeatCode_textEnd);}
    
  /** setter for textEnd - sets The Ambiguous Phrase's text end if it has any 
   * @generated
   * @param v value to set into the feature 
   */
  public void setTextEnd(int v) {
    if (AmbiguousPhrase_Type.featOkTst && ((AmbiguousPhrase_Type)jcasType).casFeat_textEnd == null)
      jcasType.jcas.throwFeatMissing("textEnd", "lu.svv.saa.maana.type.AmbiguousPhrase");
    jcasType.ll_cas.ll_setIntValue(addr, ((AmbiguousPhrase_Type)jcasType).casFeatCode_textEnd, v);}    
   
    
  //*--------------*
  //* Feature: heuristics

  /** getter for heuristics - gets heuristics decisions
   * @generated
   * @return value of the feature 
   */
  public int getHeuristics() {
    if (AmbiguousPhrase_Type.featOkTst && ((AmbiguousPhrase_Type)jcasType).casFeat_heuristics == null)
      jcasType.jcas.throwFeatMissing("heuristics", "lu.svv.saa.maana.type.AmbiguousPhrase");
    return jcasType.ll_cas.ll_getIntValue(addr, ((AmbiguousPhrase_Type)jcasType).casFeatCode_heuristics);}
    
  /** setter for heuristics - sets heuristics decisions 
   * @generated
   * @param v value to set into the feature 
   */
  public void setHeuristics(int v) {
    if (AmbiguousPhrase_Type.featOkTst && ((AmbiguousPhrase_Type)jcasType).casFeat_heuristics == null)
      jcasType.jcas.throwFeatMissing("heuristics", "lu.svv.saa.maana.type.AmbiguousPhrase");
    jcasType.ll_cas.ll_setIntValue(addr, ((AmbiguousPhrase_Type)jcasType).casFeatCode_heuristics, v);}    
  }

    