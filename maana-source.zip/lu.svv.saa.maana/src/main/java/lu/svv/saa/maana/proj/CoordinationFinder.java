package lu.svv.saa.maana.proj;


import static org.apache.uima.fit.util.JCasUtil.select;
import static org.apache.uima.fit.util.JCasUtil.selectCovered;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.regex.Pattern;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.jcas.JCas;
import org.uimafit.component.JCasAnnotator_ImplBase;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Sentence;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token;
import lu.svv.saa.maana.type.AmbiguousPhrase;


 /**
 * The Coordination finder class 
 * 
 * extends J cas annotator_ impl base
 */ 
public class CoordinationFinder extends JCasAnnotator_ImplBase {
	  public static int id=0;
	  static ArrayList<String> toSave=new ArrayList<String>();
	  static HashMap<String,String> MaptoSave=new HashMap<String,String>();
	  static ArrayList<String> ProcessedPhrases=new ArrayList<String>();
	  @Override

/** 
 *
 * Process: main function
 * 
 *  loops over sentences for patterns identification
 *
 * @param jcas  the jcas
 * @throws   AnalysisEngineProcessException 
 */
	  public void process(JCas jcas) throws AnalysisEngineProcessException { 

		 toSave=new ArrayList<String>();
		 ProcessedPhrases=new ArrayList<String>();
		  for (Sentence sentence : select(jcas, Sentence.class)) {
			  patternIdentifier(sentence,jcas);
		  }
	  }

/** 
 *
 * Check if the phrase is already processed
 *
 * @param phrase
 * @return boolean true if already processed
 */
	  public boolean checkPhrase(String phrase) { 

		  String Phrase=phrase.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
		  for(String p: Main.LocalPhrases) {
			  String P=p.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
			  if(Phrase.equals(P) || Phrase.contains(P) || P.contains(Phrase)) {
				  return true;
			  }
		  }
		  return false;
	  }

/** 
 *
 * Filter the already found phrases
 *
 * @param phrases list
 * @param lxphrases list
 * @return List<String> filtered list
 */
	  public List<String> filter(ArrayList<String> phrases,ArrayList<String> lxphrases) { 

		  if(phrases.isEmpty()) return null;
		  int lxsize= lxphrases.size();
		  for(String phraseP: phrases) {
				int f=0;
				for(String Phraselx: lxphrases) {
					String PhraseP=phraseP.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
					if(PhraseP.equals(Phraselx) || PhraseP.contains(Phraselx) || Phraselx.contains(PhraseP)) {
						lxphrases.remove(Phraselx);
						f=1;				 
					}
					if(f==1) break;
				}
			}
		  return lxphrases.subList(0, lxsize-phrases.size());
	  }

/** 
 *
 * Read phrases from the input file
 *
 * @param InputFile 
 * @return ArrayList<String> phrases list
 * @throws   IOException 
 */
		public ArrayList<String> readPhrases(String InputFile) throws IOException { 

			File file = new File(InputFile);
			BufferedReader reader = new BufferedReader(new FileReader(file));
		    String line = reader.readLine();
		    ArrayList<String> phrases= new ArrayList<String>();
		    while ( (line = reader.readLine()) != null ) {
		    	String[] fields = line.split(";");
		    	if(fields.length<3)  continue;
		    	String phrase=fields[2];
		    	phrases.add(phrase);
		    }
		    reader.close();
		    return phrases;
		}


/** 
 *
 * Gets segment text from a sentence
 *
 * @param s  the sentence
 * @param begin index
 * @param end index
 * @return the segment text
 */
	  public static String getText1(Sentence s, int begin, int end) { 

		 	StringBuilder text= new StringBuilder();
	    	for(int i=begin;i<=end;i++) 
	    		text.append(selectCovered(Token.class, s).get(i).getCoveredText()+" ");
	    	return text.toString();
	  }

/** 
 *
 * Pattern identifier
 *
 * @param sentence
 * @param jcas  the jcas
 */
	  public void patternIdentifier(Sentence sentence, JCas jcas){ 

			char conjunctsType=0;
			int size=selectCovered(Token.class, sentence).size();
			for(int i=1;i<size;i++) {
				Token token=selectCovered(Token.class, sentence).get(i);
				if(CheckCC(token) && 
						!Arrays.asList(",",".").contains(selectCovered(Token.class, sentence).get(i+1).getCoveredText())
						&& !Arrays.asList(",",".").contains(selectCovered(Token.class, sentence).get(i-1).getCoveredText())){
					if(i>1 && selectCovered(Token.class, sentence).get(i-2).getCoveredText().equals(","))  continue;
					int begin = i<4?0:i-4;
					int end = size-i<=4?size-1:i+4;
					String lxphrase=getText(sentence,begin,end);
					conjunctsType=CheckConjuncts(sentence,i);
					if (conjunctsType!=0) {
						if(!lxphrase.replaceAll("[^a-zA-Z0-9 ]", "").equals(lxphrase)) continue;
						if(ProcessedPhrases.contains(lxphrase)) continue;
						if(Main.ccPhrases.containsValue(sentence)) if(checkphrase(lxphrase,sentence)) continue;
						if(checkPhrase(lxphrase)) continue;
						AmbiguousPhrase AmbiguiousCC=new AmbiguousPhrase(jcas);
						AmbiguiousCC.setBegin(getToken(sentence, begin).getBegin());
						AmbiguiousCC.setEnd(getToken(sentence, end).getEnd());
						AmbiguiousCC.setId(0);
						AmbiguiousCC.setCCid(i-begin);
						AmbiguiousCC.setPattern("N/A");
						AmbiguiousCC.setSentence(sentence.getCoveredText().replace(";",",").replace("\n"," "));
						AmbiguiousCC.setText(lxphrase);
						AmbiguiousCC.setMid(getMid(AmbiguiousCC));
						AmbiguiousCC.addToIndexes();
						Main.ccPhrases.put(AmbiguiousCC, sentence);
						Main.LocalPhrases.add(lxphrase);
						ProcessedPhrases.add(lxphrase);
					}
					
				}
			}			
		}

/** 
 *
 * Check if the input token is a conjunction
 *
 * @param t  the token
 * @return boolean
 */
	  public static boolean CheckCC(Token t) { 

			String[] al = {"and","or","&","'n","et","nor"};
			for(String s: al) {
				if(t.getCoveredText().equalsIgnoreCase(s))
					return true;
			}
			return false;
		}

/** 
 *
 * Check if a similar sentence is already processed with the same phrase  
 *
 * @param lxphrase  the lexical phrase
 * @param sentence
 * @return boolean
 */
	  private static boolean checkphrase(String lxphrase, Sentence sentence) { 

		  String LXphrase=lxphrase.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
		  for (Entry<AmbiguousPhrase, Sentence> entry : Main.ccPhrases.entrySet()) {
		        if (entry.getValue().equals(sentence)) {
		        	String Phrase=entry.getKey().getText().replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
		        	if(Phrase.equals(LXphrase) || Phrase.contains(LXphrase) || LXphrase.contains(Phrase)) 
		        		return true;
		        }
		    }
		  return false;
	  }

/** 
 *
 * Gets the modifier index from the Coordination phrase
 *
 * @param phrase
 * @return the modifier index
 */
		  public static int getMid(AmbiguousPhrase phrase) { 

			  int ccid=phrase.getCCid();
			  boolean left=true, right=true;
			  for(int i =1; i<=Math.min(ccid,selectCovered(Token.class, phrase).size()-ccid);i++) {
				  if(left) if(checkMType(selectCovered(Token.class, phrase).get(ccid-i))) return ccid-i;
				  if(checkSpecialCharacter(selectCovered(Token.class, phrase).get(ccid-i))) left=false;
				  if(right) if(checkMType(selectCovered(Token.class, phrase).get(ccid+i))) return ccid+i;
				  if(checkSpecialCharacter(selectCovered(Token.class, phrase).get(ccid+i))) right=false;
			  }
			  if(ccid>selectCovered(Token.class, phrase).size()-ccid)
			  for(int i =selectCovered(Token.class, phrase).size()-ccid+1; i<=ccid;i++) {
				  if(!left) break;
				  if(checkMType(selectCovered(Token.class, phrase).get(ccid-i))) return ccid-i;
				  if(checkSpecialCharacter(selectCovered(Token.class, phrase).get(ccid-i))) left=false;
			  }
			  else if(ccid<selectCovered(Token.class, phrase).size()-ccid)
				  for(int i =ccid+1; i<selectCovered(Token.class, phrase).size()-ccid;i++) {
					  if(!right) break;
					  if(checkMType(selectCovered(Token.class, phrase).get(ccid+i))) return ccid+i;
					  if(checkSpecialCharacter(selectCovered(Token.class, phrase).get(ccid+i))) right=false;
				  }
			  return 0;
		  }

/** 
 *
 * Check if the token POSTag is valid for a modifier
 *
 * @param t  the token
 * @return boolean
 */
		  public static boolean checkMType(Token t) { 

			  if(t.getPosValue().toLowerCase().startsWith("n") || t.getPosValue().toLowerCase().startsWith("v") || t.getPosValue().toLowerCase().startsWith("j") || t.getPosValue().toLowerCase().startsWith("r"))
				  return true;
			  return false;
		  }

/** 
 *
 * Check if the given token had a special character
 *
 * @param t  the token
 * @return boolean
 */
		  public static boolean checkSpecialCharacter(Token t) { 

			  Pattern special = Pattern.compile (",.:;'\"[!@#$%&*()_+=|<>?{}\\[\\]~-]");
			  if(special.matcher(t.getCoveredText().toLowerCase()).find())
				  return true;
			  return false;
		  }

/** 
 *
 * Check if the conjuncts have the same POSTag
 *
 * @param sentence  the sentence
 * @param CCid  the  conjunction index 
 * @return char POSTag
 */
		public static char CheckConjuncts(Sentence sentence, int CCid) { 

			if(getPos(sentence,CCid+1).charAt(0)==getPos(sentence,CCid-1).charAt(0))
				return 'v';
			return 0;
		}

/** 
 *
 * Check pattern of a coordination phrase
 *
 * @param sentence  
 * @param CCid  the  Conjunction index
 * @param ConjunctsType  the conjuncts POSTag
 * @return int[] pattern index
 */
		public static int[] checkPattern(Sentence sentence,int CCid, char ConjunctsType) { 

				switch(ConjunctsType) {
				case 'n':
					if(getPos(sentence,CCid+2).startsWith("n")) {
						if(getPos(sentence,CCid-2).startsWith("n")) {
							return ccList(7,sentence,CCid-2,CCid+2);//nn n c n nn
							}
						else return ccList(2,sentence,CCid-1,CCid+2); //n c n nn
						}
					if(getPos(sentence,CCid-2).startsWith("n")) {
						if(getPos(sentence,CCid-3).startsWith("j"))
							return ccList(6,sentence,CCid-3,CCid+1); //adj nn n c n
						else return ccList(1,sentence,CCid-2,CCid+1); //nn n c n
						}			
					if(getPos(sentence,CCid-2).startsWith("i")) 
						if(getPos(sentence,CCid-3).startsWith("n"))
							return ccList(3,sentence,CCid-3,CCid+1); //nn p n c n
					if(getPos(sentence,CCid+2).startsWith("i")) 
						if(getPos(sentence,CCid+3).startsWith("d") || getPos(sentence,CCid+3).startsWith("j")) {
							if(getPos(sentence,CCid+4).startsWith("n")) 
							return ccList(20,sentence,CCid-1,CCid+4); //n c n p dt/adj nn
						} else if(getPos(sentence,CCid+3).startsWith("n")) 
							return ccList(4,sentence,CCid-1,CCid+3); //n c n p nn
					if(getPos(sentence,CCid+2).startsWith("v"))
						return ccList(5,sentence,CCid-1,CCid+2); //n c n vb
					if(getPos(sentence,CCid-2).startsWith("v"))
						return ccList(8,sentence,CCid-2,CCid+1); //vb n c n
					if(getPos(sentence,CCid-2).startsWith("j")) {
						if(getPos(sentence,CCid-3).startsWith("j"))
							return ccList(10,sentence,CCid-3,CCid+1); //adj adj n c n
						else return ccList(9,sentence,CCid-2,CCid+1); //adj n c n
						}
				case 'v':
					if(getPos(sentence,CCid-2).startsWith("t")) 
						if(getPos(sentence,CCid-3).startsWith("v"))
							return ccList(11,sentence,CCid-3,CCid+1); //vb to v c v
					if(getPos(sentence,CCid+2).startsWith("t")) 
						if(getPos(sentence,CCid+3).startsWith("v"))
							return ccList(12,sentence,CCid-1,CCid+3); //v c v to vb
					if(getPos(sentence,CCid-2).startsWith("r"))
						return ccList(13,sentence,CCid-2,CCid+1); //adv v c v	
					if(getPos(sentence,CCid-2).startsWith("i")) {
						if(getPos(sentence,CCid-3).startsWith("n"))
							if(getPos(sentence,CCid-4).startsWith("d") || getPos(sentence,CCid-4).startsWith("j")) {
								return ccList(21,sentence,CCid-4,CCid+1); //dt/adj nn p v c v
							} 
						return ccList(14,sentence,CCid-3,CCid+1); //nn p v c v
						}
					if(getPos(sentence,CCid+2).startsWith("i")) 
						if(getPos(sentence,CCid+3).startsWith("d") || getPos(sentence,CCid+3).startsWith("j")) {
							if(getPos(sentence,CCid+4).startsWith("n")) 
							return ccList(22,sentence,CCid-1,CCid+4); //v c v p dt/adj nn
						} else if(getPos(sentence,CCid+3).startsWith("n")) 
							return ccList(15,sentence,CCid-1,CCid+3); //v c v p nn
					if(getPos(sentence,CCid+2).startsWith("n"))
						return ccList(16,sentence,CCid-1,CCid+2); //v c v nn
					if(getPos(sentence,CCid+2).startsWith("r"))
						return ccList(17,sentence,CCid-1,CCid+2); //v c v adv
				case 'j':
					if(getPos(sentence,CCid-2).startsWith("r"))
						return ccList(18,sentence,CCid-2,CCid+1); //adv adj c adj	
					if(getPos(sentence,CCid+2).startsWith("r"))
						return ccList(19,sentence,CCid-1,CCid+2); //adj c adj adv		
			}
			return new int[] {0,0,0};
		}

/** 
 *
 * Cc list: creates output array for the identified pattern
 *
 * @param ambiguityID  the ambiguity identifier
 * @param sentence  
 * @param begin  index
 * @param end  index
 * @return int[] 
 */
		public static int[] ccList(int ambiguityID,Sentence sentence,int begin, int end) { 

			int[] list=new int[]{-9,-9,-9};
			try {
				list=new int[]{ambiguityID,getToken(sentence,begin).getBegin(),getToken(sentence,end).getEnd(),begin,end};	
				return list;
			} catch (Exception e) {
				
			}
			return list;
		} 

/** 
 *
 * Gets the POSTag of a given token by id
 *
 * @param sentence 
 * @param CCid  the  token id
 * @return the postag
 */
		public static String getPos(Sentence sentence, int CCid) { 

			String POS="-1";
			 try {
				 POS=selectCovered(Token.class, sentence).get(CCid).getPosValue().toLowerCase();
			 } catch (Exception e) {}
			 return POS;
		 }

/** 
 *
 * Gets the token by id from a sentence
 *
 * @param sentence
 * @param CCid  the token id
 * @return the token
 */
		public static Token getToken(Sentence sentence, int CCid) { 

			Token T=null;
			 try {
				 T=selectCovered(Token.class, sentence).get(CCid);
			 } catch (Exception e) {}
			 return T;
		 }

/** 
 *
 * Gets the segment text from a sentence
 *
 * @param s  the sentence
 * @param begin  the segment beginning index 
 * @param end  the segment ending index
 * @return the segment text
 */
		 public static String getText(Sentence s, int begin, int end) { 

			 	StringBuilder text= new StringBuilder();
		    	for(int i=begin;i<=end;i++) 
		    		text.append(selectCovered(Token.class, s).get(i).getCoveredText()+" ");
		    	return text.toString();
		    }
}
