package lu.svv.saa.maana.proj;


import static org.apache.uima.fit.util.JCasUtil.selectCovered;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.fit.component.JCasConsumer_ImplBase;
import org.apache.uima.fit.util.JCasUtil;
import org.apache.uima.jcas.JCas;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Sentence;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token;
import lu.svv.saa.maana.type.AmbiguousPhrase;


 /**
 * The PAA patterns finder class   
 * 
 * extends J cas consumer_ impl base
 */ 
public class PAAPattern extends JCasConsumer_ImplBase {
	private static final boolean useExtendedPatterns = Main.useExtendedPatterns;
	static Pattern p = Pattern.compile("[^a-z0-9 ]", Pattern.CASE_INSENSITIVE);
	public static String[] Patterns= {"",
			"v n p n",
			"v dt/adj n p dt/adj n",
			"v dt/adj n p n",
			"v n p dt/adj n",
			"v dt+adj n p dt/adj n",
			"v dt/adj n p dt+adj n",
			"v dt+adj n p dt+adj n",
			"v dt+adj n p n",
			"v n p dt+adj n",
			"v n n p n",
			"v dt/adj n n p n",
			"v dt+adj n n p n",
			"v n n p dt/adj n",
			"v n n p dt+adj n",
			"v dt/adj n n p dt/adj n",
			"N/A",
//			"v dt/adj n n p dt+adj n",
			"v dt+adj n n p dt/adj n",
			"v dt+adj n n p dt+adj n"
			};
	public static int[] PPiDs= {0,2,3,3,2,4,3,4,4,2,3,4,5,3,3,4,4,5,5};
	private static int[] N1IDs= {-1,1,2,2,1,3,2,3,3,1,2,3,4,2,2,3,3,4,4};
	private static int[] N2IDs= {-1,3,5,4,4,6,6,7,5,5,4,5,6,5,6,6,7,7,8};
	static ArrayList<String> localphrases=new ArrayList<String>();
	static ArrayList<String> localsentences=new ArrayList<String>();
	static ArrayList<String> toSave=null;
	static int id=0;
	static int count=0;

	@Override

/** 
 *
 * Process: main function
 * 
 * loops over sentences for patterns identification
 *
 * @param aJCas  the a J cas
 * @throws   AnalysisEngineProcessException 
 */
	public void process(JCas aJCas) throws AnalysisEngineProcessException { 

		Main.nbrOfSentences+=JCasUtil.select(aJCas, Sentence.class).size();
		Main.ppPhrases= new HashMap<AmbiguousPhrase,Sentence>(); 
		count=0;
		localphrases=new ArrayList<String>();
		toSave=new ArrayList<String>();
		for (Sentence sentence : JCasUtil.select(aJCas, Sentence.class)) {
			patternIdentifier(sentence,aJCas);
	    }
		Main.AmbiguousPhrases.addAll(localphrases);
		Main.AmbiguousSentences.addAll(localsentences);
		if(toSave.isEmpty()) return;
		Main.jcas=aJCas;
	}


/** 
 *
 * Pattern identifier from a sentence
 *
 * @param sentence 
 * @param jcas  the jcas
 */
	public static void patternIdentifier(Sentence sentence, JCas jcas){ 

		int[] PAAType= {0,0,0,0,0};
		int f=0;
		List<String> phrases = new ArrayList<String>();
		for(int i=1;i<selectCovered(Token.class, sentence).size();i++) {
			Token token=selectCovered(Token.class, sentence).get(i);
			if(token.getPos().getPosValue().equalsIgnoreCase("IN")) {// && !token.getPos().getPosValue().equalsIgnoreCase("of") && !p.matcher(token.getCoveredText()).find()){
				PAAType=checkPattern(sentence,i);
				if(PAAType[0]<=0 || PAAType.length==0)// || PAAType[0]>4)
					continue;
				AmbiguousPhrase AmbiguiousPAA=new AmbiguousPhrase(jcas);
				AmbiguiousPAA.setBegin(PAAType[1]);
				AmbiguiousPAA.setEnd(PAAType[2]);
				AmbiguiousPAA.setId(PAAType[0]);
				AmbiguiousPAA.setCCid(PPiDs[PAAType[0]]);
				AmbiguiousPAA.setMid(N1IDs[PAAType[0]]);
				AmbiguiousPAA.setN2id(N2IDs[PAAType[0]]);
				AmbiguiousPAA.setPattern(Patterns[PAAType[0]]);
				AmbiguiousPAA.setSentence(sentence.getCoveredText().replace(";",",").replace("\n"," "));
				AmbiguiousPAA.setText(getText(sentence,PAAType[3],PAAType[4]));
				AmbiguiousPAA.setHeuristics(-1);
				AmbiguiousPAA.addToIndexes();
				Main.ppPhrases.put(AmbiguiousPAA, sentence);
				phrases.add(AmbiguiousPAA.getCoveredText());
				Main.LocalPhrases.add(getText(sentence,PAAType[3],PAAType[4]));
				if(token.getCoveredText().equalsIgnoreCase("of")) count++;
				if(!localphrases.contains(AmbiguiousPAA.getCoveredText())) {
					localphrases.add(AmbiguiousPAA.getCoveredText());
				}
				if(!localsentences.contains(AmbiguiousPAA.getSentence()))
					localsentences.add(AmbiguiousPAA.getSentence());
				Main.nbrOfCOOPhrases++;
				f=1;
				
			}
		}
		if(f==1) {
			Main.nbrOfCoordinations++;
		}
	}


/** 
 *
 * Gets the postag of a token in the sentence
 *
 * @param the sentence
 * @param i  the token index
 * @return the postag
 */
	public static String getPos(Sentence sentence, int i) { 

		String POS="-1";
		 try {
			 POS=selectCovered(Token.class, sentence).get(i).getPosValue().toLowerCase();
		 } catch (Exception e) {}
		 return POS;
	 }

/** 
 *
 * Check PAA patterns 
 *
 * @param sentence  the sentence
 * @param Pid  the preposition index
 * @return int[] pattern ids
 */
	public static int[] checkPattern(Sentence sentence,int Pid) { 

		if(!getPos(sentence,Pid-1).startsWith("n")) return new int[] {0,0,0};
		if(getPos(sentence,Pid+1).startsWith("n")) {
			if(getPos(sentence,Pid-2).startsWith("v")) 
				return ppList(1,sentence,Pid-2,Pid+1);//v n p n
			else if(getPos(sentence,Pid-2).startsWith("n")) {
				if(getPos(sentence,Pid-3).startsWith("v"))
					return ppList(10,sentence,Pid-3,Pid+1);//v n n p n
				else if(getPos(sentence,Pid-3).startsWith("d") || getPos(sentence,Pid-3).startsWith("j")) {
					if(getPos(sentence,Pid-4).startsWith("v"))
						return ppList(11,sentence,Pid-4,Pid+1);//v dt/adj n n p n
					else if(getPos(sentence,Pid-4).startsWith("d") && getPos(sentence,Pid-5).startsWith("v"))
						return ppList(12,sentence,Pid-5,Pid+1);//v dt+adj n n p n
				}
			}
			else if(getPos(sentence,Pid-2).startsWith("d") || getPos(sentence,Pid-2).startsWith("j")) {
				if(getPos(sentence,Pid-3).startsWith("v"))
					return ppList(3,sentence,Pid-3,Pid+1); //v dt/adj n p n
				else if(getPos(sentence,Pid-3).startsWith("d") && getPos(sentence,Pid-4).startsWith("v"))
					return ppList(8,sentence,Pid-4,Pid+1); //v dt+adj n p n
			}
		}
		else if(getPos(sentence,Pid+1).startsWith("d") || getPos(sentence,Pid+1).startsWith("j")) {
			if(getPos(sentence,Pid+2).startsWith("n")) {
				if(getPos(sentence,Pid-2).startsWith("v"))
					return ppList(4,sentence,Pid-2,Pid+2); //v n p dt/adj n
				else if(getPos(sentence,Pid-2).startsWith("n")) {
					if(getPos(sentence,Pid-3).startsWith("v"))
						return ppList(13,sentence,Pid-3,Pid+2); //v n n p dt/adj n
					else if(getPos(sentence,Pid-3).startsWith("d") || getPos(sentence,Pid-3).startsWith("j"))
						if(getPos(sentence,Pid-4).startsWith("v"))
							return ppList(15,sentence,Pid-4,Pid+2); //v dt/adj n n p dt/adj n
						else if(getPos(sentence,Pid-4).startsWith("d") && getPos(sentence,Pid-5).startsWith("v"))
							return ppList(17,sentence,Pid-5,Pid+2); //v dt+adj n n p dt/adj n
				}
				else if(getPos(sentence,Pid-2).startsWith("d") || getPos(sentence,Pid-2).startsWith("j")) {
					if(getPos(sentence,Pid-3).startsWith("v"))
						return ppList(2,sentence,Pid-3,Pid+2);//v dt/adj n p dt/adj n
					else if(getPos(sentence,Pid-3).startsWith("d") && getPos(sentence,Pid-4).startsWith("v"))
						return ppList(5,sentence,Pid-4,Pid+2);//v dt+adj n p dt/adj n
				}
			} else if(getPos(sentence,Pid+2).startsWith("j") && getPos(sentence,Pid+3).startsWith("n")) {
				if(getPos(sentence,Pid-2).startsWith("v"))
					return ppList(9,sentence,Pid-2,Pid+3);//v n p dt+adj n
				if(getPos(sentence,Pid-2).startsWith("n")) {
					if(getPos(sentence,Pid-3).startsWith("v"))
						return ppList(14,sentence,Pid-3,Pid+3);//v n n p dt+adj n
					else if(getPos(sentence,Pid-3).startsWith("d") || getPos(sentence,Pid-3).startsWith("j"))
						if(getPos(sentence,Pid-4).startsWith("v"))
							return ppList(16,sentence,Pid-4,Pid+3);//v dt/adj n n p dt+adj n
						else if(getPos(sentence,Pid-4).startsWith("d") && getPos(sentence,Pid-5).startsWith("v"))
							return ppList(18,sentence,Pid-5,Pid+3);//v dt+adj n n p dt+adj n
				}
				else if(getPos(sentence,Pid-2).startsWith("d") || getPos(sentence,Pid-2).startsWith("j"))
					if(getPos(sentence,Pid-3).startsWith("v"))
						return ppList(6,sentence,Pid-3,Pid+3);//v dt/adj n p dt+adj n
					else if(getPos(sentence,Pid-3).startsWith("d") && getPos(sentence,Pid-4).startsWith("v"))
						return ppList(7,sentence,Pid-4,Pid+3);//v dt+adj n p dt+adj n
			}
		}	
		return new int[] {0,0,0};
	}

/** 
 *
 * Gets the segment text from the sentence
 *
 * @param s  the sentence
 * @param begin  the segment begin index
 * @param end  the segment end index
 * @return the segment text
 */
	public static String getText(Sentence s, int begin, int end) { 

		 	StringBuilder text= new StringBuilder();
	    	for(int i=begin;i<=end;i++) 
	    		text.append(selectCovered(Token.class, s).get(i).getCoveredText()+" ");
	    	return text.toString();
    }


/** 
 *
 * Pp list: PAA pattern identifier output array
 *
 * @param ambiguityID  the ambiguity identifier
 * @param sentence  the sentence
 * @param begin index
 * @param end index
 * @return int[]
 */
	public static int[] ppList(int ambiguityID,Sentence sentence,int begin, int end) { 

		if(!useExtendedPatterns)
			if(ambiguityID>4) return new int[] {0,0,0};
		return new int[]{ambiguityID,getToken(sentence,begin).getBegin(),getToken(sentence,end).getEnd(),begin,end};
	} 

/** 
 *
 * Gets the token by index from the sentence
 *
 * @param the sentence
 * @param i  the token index
 * @return the token
 */
	public static Token getToken(Sentence sentence, int i) { 

		Token T=null;
		 try {
			 T=selectCovered(Token.class, sentence).get(i);
		 } catch (Exception e) {}
		 return T;
	 }


}
