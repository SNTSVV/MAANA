/**
 * Copyright by University of Luxembourg (c) 2021
 * Developed by [Saad Ezzini, saad.ezzini@uni.lu] 
 * and [Sallam Abualhaija, sallam.abualhaija@uni.lu]
 */
/**
 * @author saad.ezzini
 *
 */
package lu.svv.saa.maana.proj;
