package lu.svv.saa.maana.proj;


import static org.apache.uima.fit.util.JCasUtil.selectCovered;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.stream.Collectors;

import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.fit.component.JCasConsumer_ImplBase;
import org.apache.uima.fit.util.JCasUtil;
import org.apache.uima.jcas.JCas;

import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token;
import de.tudarmstadt.ukp.dkpro.core.api.syntax.type.constituent.NP;


 /**
 * The Keywords extraction class 
 * 
 * extends J cas consumer_ impl base
 */ 
public class Keywords extends JCasConsumer_ImplBase {
	JCas aJCas;
	boolean LEMMATIZE = true;
	HashMap<String,Integer> Freqs=null;
	HashMap<String,Float> TFIDF = null;
	ArrayList<String> StopWords = null;
	ArrayList<String> wordsOfDoc= null;
	HashMap<Double,String> encodedWords = new HashMap<Double,String>();
	int Limit = 100;
	String Stop_Words = readfile(Main.stopWordsPath);
	@Override

/** 
 *
 * Process: main function
 * 
 * 
 *
 * @param aJCas  the a J cas
 * @throws   AnalysisEngineProcessException 
 */
	public void process(JCas aJCas) throws AnalysisEngineProcessException { 

		start();
		this.aJCas=aJCas;
		StopWords=getStopWords(Stop_Words);
		wordsOfDoc= WordsOf(true);
		Freqs=MapFreq(wordsOfDoc);
		TFIDF=MapDoc(wordsOfDoc);
		ArrayList<String> sortedKeywords = filter(sortMap(getNpTfIdf(getAtomicNPs(JCasUtil.select(aJCas, NP.class))), Limit));
		Main.keywords.addAll(sortedKeywords);
		removeDuplicates(Main.keywords);
	}

/** 
 *
 * Start: initialize variables
 *
 */
	public void start() { 

		encodedWords = new HashMap<Double,String>();
		wordsOfDoc= null;
		StopWords = null;
		TFIDF = null;
		Freqs=null;
	}

/** 
 *
 * Filter out tiny and empty keywords
 *
 * @param sortedKeywords
 * @return ArrayList<String>
 */
	public ArrayList<String> filter(ArrayList<NP> sortedKeywords) { 

		ArrayList<String> finalList= new ArrayList<String>();
		for(NP np: sortedKeywords) {
			String phrase=npToString(np);
			if(phrase.length()<2) continue;
			finalList.add(phrase);
		}
		return finalList;
	}

/** 
 *
 * Noun phrase to string conversion
 *
 * @param np  the noun phrase object
 * @return String
 */
	public String npToString(NP np) { 

		StringBuilder sb = new StringBuilder();
		for(Token t: selectCovered(Token.class, np))
			if(LEMMATIZE)
				sb.append(t.getLemmaValue()+" ");
			else sb.append(t.getCoveredText()+" ");
		return sb.toString().replaceAll("\\s+"," ").trim();
	}

/** 
 *
 * Gets the noun phrases tf-idf
 *
 * @param nps  the noun phrases list
 * @return the tf idf list
 */
	public HashMap<NP,Float> getNpTfIdf(ArrayList<NP> nps) { 

		HashMap<NP,Float> NpsMeasures = new HashMap<NP,Float>();
		for(NP np: nps) 
			NpsMeasures.put(np, nounPhraseTFIDF(np));
		return NpsMeasures;
	}

/** 
 *
 *  TFIDF of a Noun phrase
 *
 * @param np  the Noun phrase
 * @return Float 
 */
	public Float nounPhraseTFIDF(NP np) { 

		Float totalTFIDF=(float) 0;
		int nbrOfTokens=0;
		for(Token t: selectCovered(Token.class, np)) {
			String word=t.getCoveredText();
			if(!TFIDF.containsKey(word)) continue;
			nbrOfTokens++;
			totalTFIDF+=TFIDF.get(word);
		}
		return totalTFIDF/nbrOfTokens;
	}

/** 
 *
 * Remove duplicates
 *
 * @param arrayList  the array list
 * @return ArrayList<T>
 */
	public <T> ArrayList<T> removeDuplicates(ArrayList<T> arrayList) { 

        Set<T> set = new LinkedHashSet<T>();
        set.addAll(arrayList); 
        arrayList.clear(); 
        arrayList.addAll(set); 
        return arrayList;
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })

/** 
 *
 * Sort map
 * 
 * @param map
 * @param limit: take top <limit> elements from the sorted map
 * @return ArrayList<NP>
 */
	public ArrayList<NP> sortMap(HashMap<NP,Float> map,int limit){ 

		HashMap<NP,Float> sorted= map.entrySet().stream()
	        .sorted(Collections.reverseOrder(Map.Entry.comparingByValue())).limit(limit).collect(
    		Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e2, LinkedHashMap::new));
		return new ArrayList(sorted.keySet());
	}

/** 
 *
 * Gets the atomic Noun phrases
 *
 * @param nps  the Noun phrases
 * @return the atomic Noun phrases
 */
	public ArrayList<NP> getAtomicNPs(Collection<NP> nps) { 

		ArrayList<NP> sentence= new ArrayList<NP>();
		ArrayList<NP> toRemove= new ArrayList<NP>();
		ArrayList<NP> atomicNP= new ArrayList<NP>();
		for(NP np: nps) {
			if(sentence.isEmpty()) {
				sentence.add(np);
				continue;
			}
			boolean match=false;
			for(NP s: sentence)
				if(s.getCoveredText().contains(np.getCoveredText())) {
					match=true;
					toRemove.add(s);
				}
			if(match) sentence.add(np);
			else {
				toRemove=removeDuplicates(toRemove);
				sentence.removeAll(toRemove);
				atomicNP.addAll(sentence);
				sentence.clear();
				toRemove.clear();
			}
		}
		return atomicNP;
	}

/** 
 *
 * Map document with TFIDF values
 *
 * @param ArrayList<String>  the array list words within a document
 * @return HashMap<String,Float>
 */
	public HashMap<String,Float> MapDoc(final ArrayList<String> Doc) { 

		HashMap<String,Float> Mp= new HashMap<String,Float>();
		for(String word : UniqueWords(Doc)){
			float IDF = IDF1doc(word,Doc);
			float TF = TF(word,Doc);
			Mp.put(word, (float) TF*IDF);
		}
		return Mp;
	}

/** 
 *
 * Map frequency
 *
 * @param Doc  the document as list of words
 * @return HashMap<String,Integer>
 */
	public HashMap<String,Integer> MapFreq(ArrayList<String> Doc) { 

		HashMap<String,Integer> Mp= new HashMap<String,Integer>();
		for(String word : UniqueWords(Doc)){
			Mp.put(word,Freq(word,Doc));
		}
		return Mp;
	}

/** 
 *
 * Cosine similarity
 *
 * @param query
 * @param Doc  the document
 * @return double
 */
	public double cosineSimilarity(String query, ArrayList<String> Doc){ 

		double[][] queryVector= processWord(ppText(query));
		double multiple = 0 ;
		double sum1 = 0 ;
		double sum2 = 0 ;
		for(int i = 0 ; i < queryVector.length ; i++){
			String word = encodedWords.get(queryVector[i][0]);
			if(wordsOfDoc.contains(word)){
				double currentWordTFIDF= TFIDF.get(word);
				multiple+=(double) queryVector[i][2]*currentWordTFIDF;
				sum1+=Math.pow(currentWordTFIDF, 2);
			}
			sum2+=Math.pow((double) queryVector[i][1], 2);
		}
		double cosineSimilarity = multiple/((Math.pow(sum1, (double)1/2))*Math.pow(sum2, (double) 1/2));
		return cosineSimilarity;
	}

/** 
 *
 * Process create query vector
 *
 * @param query
 * @return [][]
 */
	public double [][] processWord(String query){ 

		String terms[] = query.split(" ");
		double [][] queryVector = new double[terms.length][3];
		float count = (float)1/terms.length;
		for(int i = 0 ; i < terms.length ; i++ ){
			String word = terms[i].toLowerCase();
			if(wordsOfDoc.contains(word)){
				queryVector[i][0] = word.hashCode() ;
				encodedWords.put((double) word.hashCode(), word);
				queryVector[i][1] = IDF1doc(word, wordsOfDoc);
				queryVector[i][2] = count*((double) queryVector[i][1]);
			}
			else {
				queryVector[i][0] = word.hashCode() ;
				encodedWords.put((double) word.hashCode(), word);
				queryVector[i][1] = 0;
				queryVector[i][2] = 0;
			}
		}
		return queryVector;
	}

/** 
 *
 * preprocess text removing stopwords
 *
 * @param text  
 * @return String preprocessed text
 */
	public String ppText(String text){ 

		String listString = "";
		for(String S : removeStopWords(text,Stop_Words))
			listString += S+" ";
		return listString;
	}

/** 
 *
 * Gets the frequency of a query if a document
 *
 * @param query  
 * @param doc  
 * @return Integer
 */
	public Integer Freq(String query, ArrayList<String> doc){ 

		int c=0;
		for(String term : doc)
			if(query.equals(term)) c++;
		return c;
	} 

/** 
 *
 *  TF : Term Frequency
 *
 * @param Word  
 * @param Doc  
 * @return float
 */
	public float TF(String Word,ArrayList<String> Doc){ 

		float f = (float) Freqs.get(Word) / Doc.size();
		return f;
	}

/** 
 *
 *  IDF: inverse documents frequency
 *
 * @param word  
 * @param documents list
 * @return float
 */
	public float IDF(String word, ArrayList<ArrayList<String>> documents){ 

		int cmp=0;
		for(ArrayList<String> doc : documents)
			if(documents.size()>1) cmp +=Freq(word,doc); 
			else cmp +=Freqs.get(word);
		if(cmp == 0) return 0;
		return (float) Math.log((float)documents.size()/cmp);
	}

/** 
 *
 * IDF for one document
 *
 * @param word
 * @param document  the document
 * @return float
 */
	public float IDF1doc(String word, ArrayList<String> document){ 

		int freq =0; 
		freq+=Freqs.get(word);
		if(freq == 0) return 0;
		return (float) Math.log((float)1/freq);
	}

/** 
 *
 * Unique words
 *
 * @param Words
 * @return ArrayList<String>
 */
	public ArrayList<String> UniqueWords(ArrayList<String> Words) { 

		ArrayList<String> uniqueWords = new ArrayList<String>();
		uniqueWords.addAll(Words);
		Set<String> hs = new HashSet<String>();
		hs.addAll(uniqueWords);
		uniqueWords.clear();
		uniqueWords.addAll(hs);
		Collections.sort(uniqueWords);	
		return uniqueWords;
	}

/** 
 *
 * Get all words of the document
 *
 * @param Stem words if true
 * @return ArrayList<String> words list
 */
	public ArrayList<String> WordsOf(Boolean Stem){ 

		ArrayList<String> Words = new ArrayList<String>();
		for(Token t: JCasUtil.select(aJCas, Token.class)) {
			if(t==null) continue;
			if(StopWords.contains(t.getStemValue())) continue;
			if(Stem) 
				Words.add(removeAccent(t.getStemValue().toLowerCase()));
			else Words.add(removeAccent(t.getCoveredText().toLowerCase()));
		}
		return Words;
	}

/** 
 *
 * Remove stop words
 *
 * @param text  
 * @param Stop_Words list
 * @return ArrayList<String>
 */
	public static ArrayList<String> removeStopWords(String text, String Stop_Words){ 

		StringTokenizer S = new StringTokenizer(removeAccent(text.toLowerCase()), "1234567890	\n \t«²°».,’;:/?!#(){}[]@=+_-\'\"");
		return removeFrom(S,getStopWords(Stop_Words));
	}

/** 
 *
 * Gets the stop words
 *
 * @param Words
 * @return the stop words
 */
	public static ArrayList<String> getStopWords(String Words){ 

		StringTokenizer Stop_Words = new StringTokenizer(Words, ", ");
		ArrayList<String> Stop_Words2 = new ArrayList<String>();
		while(Stop_Words.hasMoreTokens()){
			Stop_Words2.add(Stop_Words.nextToken());
		}
		return Stop_Words2;
	}

/** 
 *
 * Remove a string from a list
 *
 * @param StringTokenizer  the string to remove
 * @param ArrayList<String>  the array list of strings
 * @return ArrayList<String>
 */
	public static ArrayList<String> removeFrom(final StringTokenizer S, final ArrayList<String> Stop_Words){	 

		ArrayList<String> newListe = new ArrayList<String>();
		while(S.hasMoreTokens()){
			String X;
			X = S.nextToken();
			if(!Stop_Words.contains(X))
				newListe.add(X);
		}
		return newListe;
	}

/** 
 *
 * Remove accents from a source string
 *
 * @param source
 * @return String
 */
	public static String removeAccent(String source) { 

		return Normalizer.normalize(source, Normalizer.Form.NFD).replaceAll("[\u0300-\u036F]", "");
	}

/** 
 *
 * Readfile
 *
 * @param url 
 * @return String
 */
	public static String readfile(String url){ 

		File fileDir = new File(url);
		String texte="";
		try {
			BufferedReader bf = new BufferedReader(new InputStreamReader( new FileInputStream(fileDir), "utf-8"));
			String input = bf.readLine();
			while(input!=null){
				texte = texte.concat(input);
				input = bf.readLine();
			}
			bf.close();
			return texte;
		} catch(Exception ex){System.out.println(ex.toString());}
		return texte;
	}
}
