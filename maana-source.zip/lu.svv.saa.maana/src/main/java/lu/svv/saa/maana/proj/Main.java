package lu.svv.saa.maana.proj;


import static org.apache.uima.fit.factory.AnalysisEngineFactory.createEngineDescription;
import static org.apache.uima.fit.factory.CollectionReaderFactory.createReaderDescription;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Pattern;
import org.apache.uima.UIMAException;
import org.apache.uima.analysis_engine.AnalysisEngineDescription;
import org.apache.uima.collection.CollectionReaderDescription;
import org.apache.uima.fit.pipeline.SimplePipeline;
import org.apache.uima.jcas.JCas;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Sentence;
import de.tudarmstadt.ukp.dkpro.core.dictionaryannotator.DictionaryAnnotator;
import de.tudarmstadt.ukp.dkpro.core.io.text.TextReader;
import de.tudarmstadt.ukp.dkpro.core.languagetool.LanguageToolSegmenter;
import de.tudarmstadt.ukp.dkpro.core.opennlp.OpenNlpChunker;
import de.tudarmstadt.ukp.dkpro.core.opennlp.OpenNlpParser;
import de.tudarmstadt.ukp.dkpro.core.snowball.SnowballStemmer;
import de.tudarmstadt.ukp.dkpro.core.stanfordnlp.StanfordLemmatizer;
import de.tudarmstadt.ukp.dkpro.core.stanfordnlp.StanfordPosTagger;
import lu.svv.saa.maana.type.AmbiguousPhrase;


 /**
 * The Main class for running the approach
 */ 
public class Main {
	public static final boolean UseWeightedVotes = true;
	public static final boolean UseBNC = false;
	public static final boolean UseOptimalThresholds = true;
	public static final HashMap<String,Integer> resolvedPhrases = null;
	public static boolean useExtendedPatterns=true;
	public static boolean ss=false;
	public static boolean useOffsets=true;
	public static boolean detailedOutput=false;
	public static String var="V15";
	
	public static int nbrOfSentences=0;
	public static int nbrOfCoordinations=0;	
	public static int nbrOfCOOPhrases=0;
	public static int sentencesIndex=0;
	public static int t=0,d=0;
	public static ArrayList<String> allPhrases=new ArrayList<String>();
	public static ArrayList<String> toSave=new ArrayList<String>();
	public static ArrayList<String> processedPhrases=new ArrayList<String>();
	public static ArrayList<String> AmbiguousPhrases=new ArrayList<String>();
	public static ArrayList<String> LocalPhrases=new ArrayList<String>();
	public static ArrayList<String> AmbiguousSentences=new ArrayList<String>();
	public static HashMap<AmbiguousPhrase,Sentence> ccPhrases=new HashMap<AmbiguousPhrase,Sentence>();
	public static HashMap<AmbiguousPhrase,Sentence> ppPhrases=new HashMap<AmbiguousPhrase,Sentence>();
	public static ArrayList<String> keywords= new ArrayList<String>();
	public static double[] decisionsThresholds= {0,0.12,0,3};
	public static double lastscore =0; 
	public static Integer[] DSCParameters= {500,1000,500};
	public static long start = System.currentTimeMillis();
	public static double[] ppThresholds= {0.01,0.001};
	public static JCas jcas;
	public static Pattern p = Pattern.compile("[^a-z0-9 ]", Pattern.CASE_INSENSITIVE);
	public static int domain=-1;
	public static String Corpus= "";
	public static String DataPath= "data/";
	public static String stopWordsPath= "src/main/resources/stopwords.txt";
	public static Boolean localcorpus= false;
	static final String choiceKey="-choice";
    static final String corpusKey="-corpus";
    static final String pathKey="-doc";
    static final String expKey="true";
    static final String outputDir="";
    static int choiceValue=1;
	static String corpusValue="corpus/mini-corpus";
	static String PREP_LIST_PATH = "src/main/resources/prepositions.lst";
	

/** 
 *
 * Main function
 *
 * @param args : the command line arguments
 * 			-doc [path to the input document]
 * 			-corpus [0-7] ("mini-corpus" for a reduced corpus of Satellite 
 *                          or "new-corpus" for generating a new corpus)
 * @throws   UIMAException
 * @throws  IOException 
 */
	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws UIMAException, IOException { 


		String inputpath="src/main/resources/sample.txt";
		CollectionReaderDescription reader = createReaderDescription(TextReader.class,
				TextReader.PARAM_PATH, inputpath,
				TextReader.PARAM_LANGUAGE, "en");
		// Tokenizer
		AnalysisEngineDescription segmenter = createEngineDescription(LanguageToolSegmenter.class);
        // POS-Tagger
		AnalysisEngineDescription posTagger = createEngineDescription(StanfordPosTagger.class);
		AnalysisEngineDescription lemmatizer = createEngineDescription(StanfordLemmatizer.class);
		AnalysisEngineDescription stemmer = createEngineDescription(SnowballStemmer.class);
		// Chunker
		AnalysisEngineDescription parser = createEngineDescription(OpenNlpParser.class);
		AnalysisEngineDescription chunker = createEngineDescription(OpenNlpChunker.class);
	    AnalysisEngineDescription CAPatternIdentifier = createEngineDescription(CAPattern.class);
	    AnalysisEngineDescription PAAPatternIdentifier = createEngineDescription(PAAPattern.class);
	    AnalysisEngineDescription CADS = createEngineDescription(DomainSpecificHeuristicsCA.class);
	    AnalysisEngineDescription PAADS = createEngineDescription(DomainSpecificHeuristicsPAA.class);
	    
		AnalysisEngineDescription glossary = createEngineDescription(Glossary.class);
		AnalysisEngineDescription Keywords = createEngineDescription(Keywords.class);
		AnalysisEngineDescription wiki = createEngineDescription(WikipediaCorpusCreator.class);
		AnalysisEngineDescription ngrams = createEngineDescription(ngrams.class); 
		AnalysisEngineDescription prepFinder = createEngineDescription(DictionaryAnnotator.class,
	          DictionaryAnnotator.PARAM_MODEL_LOCATION, PREP_LIST_PATH);
	    AnalysisEngineDescription coofinder = createEngineDescription(CoordinationFinder.class);
	    AnalysisEngineDescription ppfinder = createEngineDescription(PPAttachmentFinder.class);
	    
	    
	    String corpus=corpusValue;
	    int choice=1;
	    String path="";
	    if(args.length!=0) {
	    	String pathValue="";
	    
	    for(int i=0; i<args.length; i+=2)
	    {
	        String key = args[i];
	        String value = args[i+1];

	        switch (key)
	        {
	        	case expKey:
	        		if(value.equals("false"))
	        			useExtendedPatterns=false; 
	        		break;
	        	case pathKey : 
	        		ss=false;
	        		pathValue = value; break;
	            case choiceKey : 
	            	choiceValue = Integer.parseInt(value); break;
	            case corpusKey : 
	            	corpusValue = value; break;
	        }
	    }
	    path=pathValue; // Path to the input document
    	reader = createReaderDescription(TextReader.class,
					TextReader.PARAM_PATH, path,
					TextReader.PARAM_LANGUAGE, "en");

	    
	    choice=choiceValue;
	    corpus=corpusValue; // corpus choice: existing corpus: 1-7, "new-corpus"-generates from Wikipedia (you need a local wikipedia dump)
	    }

	    switch (corpus) {
	    case "corpus/mini-corpus":
	    	Corpus+=corpus;
	    	utils.readHeuristics=true;
	    	break;
		case "new-corpus":
		    SimplePipeline.runPipeline(reader, segmenter, posTagger, lemmatizer, stemmer,chunker, parser, glossary, Keywords, wiki, ngrams);
		    Corpus+=inputpath.split("/")[inputpath.split("/").length-1].split("\\.")[0]+"-"+Main.DSCParameters[0]+"-"+Main.DSCParameters[1]+"-"+Main.DSCParameters[2];
			break;
		default:
			File f = new File(corpus);
			if (f.exists()) {
				Corpus+=corpus+"/";
			} else {
			System.out.println("\nInvalid corpus path"
					+"\nPossible values of the variable 'corpus':\n"
					+ "corpus/mini-corpus \n"
					+ "USE EXISTING CORPORA : 1-8 \n"
					+ "\tcorpus/1- Aerospace\n"
					+ "\tcorpus/2- Automotive\n"
					+ "\tcorpus/3- Defense\n"
					+ "\tcorpus/4- Digitalization\n"
					+ "\tcorpus/5- Medicine\n"
					+ "\tcorpus/6- Satellite\n"
					+ "\tcorpus/7- Security\n"
					+ "new-corpus generates a new corpus from Wikipedia using the input file\n");
			}
			break;
		}
	    
	    switch (choice) {
		case 1:
		    SimplePipeline.runPipeline(reader, segmenter, posTagger,lemmatizer, stemmer,chunker, parser, CAPatternIdentifier, coofinder, CADS);
		    SimplePipeline.runPipeline(reader, segmenter, posTagger,lemmatizer, stemmer,chunker, parser, prepFinder, PAAPatternIdentifier, ppfinder, PAADS);

			break;
//		case 2:
//			SimplePipeline.runPipeline(reader, segmenter, posTagger,lemmatizer, stemmer,chunker, parser, CAPatternIdentifier, coofinder, CADS);
//			break;
//		case 3:
//			SimplePipeline.runPipeline(reader, segmenter, posTagger,lemmatizer, stemmer,chunker, parser, prepFinder, PAAPatternIdentifier, ppfinder, PAADS);
//			break;
		default:
			System.out.println("Possible values of the variable 'choice': \n"
					+ "1-Run CA and PAA pipelines \n"
					+ "2- Run CA pipeline\n"
					+ "3- Run PAA pipeline\n");
			break;
		}
		printTime(start);

	}
	

/** 
 *
 * Print time needed to run the approach
 *
 * @param start:  the start running time
 */
	public static void printTime(long start) { 

		long end = System.currentTimeMillis();
    	float sec = (end - start) / 1000F; 
		System.out.println(sec + " seconds");
	}

/** 
 *
 * Save arraylist to file
 *
 * @param filename
 * @param toSave: the arraylist of strings
 * @throws   FileNotFoundException 
 */
	public static void saveFile(String filename,ArrayList<String> toSave) throws FileNotFoundException { 

		PrintWriter pw = new PrintWriter(new File(filename));
        for(String line: toSave)
        	pw.write(line+"\n");
        pw.close();
	}

/** 
 *
 * Save AmbiguousSentences
 *
 * @param filename
 * @throws   IOException 
 */
	public static void saveArrayList(String filename) throws IOException { 

		FileWriter writer = new FileWriter(filename); 
		for(int i =0;i<AmbiguousSentences.size();i++) {
			StringBuilder sb = new StringBuilder();
	        sb.append(AmbiguousSentences.get(i));
	        sb.append('\n');
	        writer.write(sb.toString());
		}
		writer.close();
	}

/** 
 *
 * List of files in a folder
 *
 * @param File: the folder
 * @return ArrayList<File>: list of files
 */
	public static ArrayList<File> listFilesForFolder(final File folder) { 

		ArrayList<File> docs= new ArrayList<File>();
		for (final File fileEntry : folder.listFiles()) {
	        if (fileEntry.isDirectory()) {
	        	docs.addAll(listFilesForFolder(fileEntry));
	        } else {
	        	if(fileEntry.getName().charAt(0)=='.') continue;
	            docs.add(fileEntry);
	        }
	    }
	    return docs;
	}

/** 
 *
 * Refresh the main arraylists
 *
 */
	public static void refresh() { 

		processedPhrases=new ArrayList<String>();
		AmbiguousPhrases=new ArrayList<String>();
		LocalPhrases=new ArrayList<String>();
		AmbiguousSentences=new ArrayList<String>();
		ccPhrases=new HashMap<AmbiguousPhrase,Sentence>();
	}
}

