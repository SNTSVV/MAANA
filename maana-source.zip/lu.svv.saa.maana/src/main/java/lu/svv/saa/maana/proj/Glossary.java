package lu.svv.saa.maana.proj;


import static org.apache.uima.fit.util.JCasUtil.selectCovered;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.StringTokenizer;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.fit.component.JCasConsumer_ImplBase;
import org.apache.uima.fit.util.JCasUtil;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.tcas.Annotation;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token;
import de.tudarmstadt.ukp.dkpro.core.api.syntax.type.constituent.NP;
import net.sf.extjwnl.JWNLException;
import net.sf.extjwnl.dictionary.Dictionary;


 /**
 * The class Glossary: to extract glossary terms from the input document 
 * 
 * extends J cas consumer_ impl base
 */ 
public class Glossary extends JCasConsumer_ImplBase {
	JCas aJCas;
	ArrayList<ArrayList<Token>> glossaryTerms= new ArrayList<ArrayList<Token>>();
	ArrayList<String> finalList = new ArrayList<String> ();
	ArrayList<NP> nounPhrases_cleaned = new ArrayList<NP> ();
	boolean LEMMATIZE = true;
	Set<String> set = new LinkedHashSet<String>();
	private Dictionary dict;
	int MaxItems=100;
	@Override

/** 
 *
 * Process: main function
 *
 * @param aJCas  the a J cas
 * @throws   AnalysisEngineProcessException 
 */
	public void process(JCas aJCas) throws AnalysisEngineProcessException { 

		start();
		WordNetUtils();
		this.aJCas=aJCas;
		Collection<NP> nounPhrases = JCasUtil.select(aJCas, NP.class);
		getAtomicNPs(nounPhrases);
		nounPhrases=nounPhrases_cleaned;
		fill(nounPhrases); 
		filter();
		removeDuplicates();
		if(MaxItems>0)
			if(finalList.size()<=MaxItems)
				Main.keywords.addAll(finalList);
			else 
				Main.keywords.addAll(finalList.subList(0, MaxItems));
		else 
			Main.keywords.addAll(finalList);
		System.out.println(finalList.size());
	}

/** 
 *
 * Start: initialize variables
 *
 */
	public void start() { 

		glossaryTerms= new ArrayList<ArrayList<Token>>();
		finalList = new ArrayList<String> ();
		nounPhrases_cleaned = new ArrayList<NP> ();
		set = new LinkedHashSet<String>();
	}
	

/** 
 *
 * Preprocess noun phrases
 *
 * @param nounPhrases  the noun phrases
 */
	public void fill(Collection<NP> nounPhrases) { 

		NP np0=null;
		for (Iterator<NP> npi = nounPhrases.iterator(); npi.hasNext();) {
			NP np = npi.next();
			try {
				clear(np);
			} catch (JWNLException e) {
				e.printStackTrace();
			}
			if(np0!=null) {
				checkNext(np0, np);
			}
			np0=np;
        }
	}

/** 
 *
 * Clear tiny, empty and invalid noun phrases
 * select proper nouns, Uppercase nouns, and not-in-wordnet-dictionary words within a noun phrase
 * add them to the glossary terms list
 *
 * @param np  the nounphrase
 * @throws   JWNLException 
 */
	public void clear(NP np) throws JWNLException { 

		ArrayList<Token> newNp= new ArrayList<Token>();
		ArrayList<Token> nnp= new ArrayList<Token>();
		String npText = np.getCoveredText();
		for(Token t: selectCovered(Token.class, np)){
			if(t.getCoveredText().replaceAll("[^a-zA-Z']", "").isEmpty()) {
				npText.replace(t.getCoveredText(), "");
				continue;
			}
			if(Arrays.asList("NNP","NNPS").contains(t.getPosValue())) {
				nnp.add(t);
			} else {
				if(nnp.size()>0) {
					glossaryTerms.add(nnp);
					nnp.clear();
				}
			}
			if(Arrays.asList("CD","DT","PDT","PRP$",".",":",",").contains(t.getPosValue())) {
				npText.replace(t.getCoveredText(), "");
				continue;
			}
				if(t.getCoveredText().replaceAll("[^a-zA-Z]", "").equals(t.getCoveredText().toUpperCase())){
					glossaryTerms.add(new ArrayList<Token>(Arrays.asList(t))); 
				}
				newNp.add(t);
		}
		if(nnp.size()>0) {
			glossaryTerms.add(nnp);
		}
		b:if((new StringTokenizer(npText)).countTokens()==1) {
			if(npText.replaceAll("[^a-zA-Z]", "").length()<2) return;
			if(npText.replaceAll("[^a-zA-Z]", "").equals(npText.toUpperCase()))
				break b;
			if(dict.lookupAllIndexWords(npText)!=null) return;
		}
		a:if(newNp.size()==1) {
			if(newNp.get(0).getCoveredText().replaceAll("[^a-zA-Z]", "").length()<2) return;
			if(newNp.get(0).getCoveredText().replaceAll("[^a-zA-Z]", "").equals(newNp.get(0).getCoveredText().toUpperCase()))
				break a;
			if(dict.lookupAllIndexWords(newNp.get(0).getLemmaValue())!=null) return;
		}
		glossaryTerms.add(newNp);
	}

/** 
 *
 * Check if two consecutive noun phrases have "Possessive ending" or "To" in between then combine them
 *
 * @param np1  nounPhrase 1
 * @param np2  nounPhrase 2
 */
	public void checkNext(NP np1, NP np2) { 

		Annotation a = new Annotation(aJCas);
		a.setBegin(np1.getEnd()); a.setEnd(np2.getBegin());
		if(selectCovered(Token.class, a).size()>1 || selectCovered(Token.class, a).isEmpty()) return;
		ArrayList<Token> npPhrase= new ArrayList<Token>();
		if(Arrays.asList("TO","POS").contains(selectCovered(Token.class, a).get(0).getPosValue())) {
			npPhrase.addAll(selectCovered(Token.class, np1));
			npPhrase.add(selectCovered(Token.class, a).get(0));
			npPhrase.addAll(selectCovered(Token.class, np2));
		}
		glossaryTerms.add(npPhrase);
	}

/** 
 *
 * Load WordNet dictionary
 *
 */
	public void WordNetUtils() { 

		try {
			dict = Dictionary.getDefaultResourceInstance();
		} catch (JWNLException e) {
			e.printStackTrace();
		}
	}

/** 
 *
 * Filter out tiny noun phrases and sort them by length
 *
 */
	public void filter() { 

		for(ArrayList<Token> np: glossaryTerms) {
			String phrase=npToString(np);
			if(phrase.length()<2) continue;
			finalList.add(phrase);
		}
		Collections.sort(finalList, new Comparator<String>() {

            

/** 
 *
 * Compare function (used to sort keywords)
 *
 * @param o1  the o1
 * @param o2  the o2
 * @return int
 */
            public int compare(String o1, String o2) { 

                if(o1.length()>o2.length()){
                    return -1;
                }else if(o1.length()<o2.length()){ 
                	return 1;
                } else {
                    return 0;
                }
            }
        });		
	}

/** 
 *
 * convert the input noun phrase to string format
 *
 * @param np:  the input noun phrase in token list format
 * @return String noun phrase
 */
	public String npToString(ArrayList<Token> np) { 

		StringBuilder sb = new StringBuilder();
		for(Token t: np)
			if(LEMMATIZE)
				sb.append(t.getLemmaValue()+" ");
			else sb.append(t.getCoveredText()+" ");
		return sb.toString().replaceAll("\\s+"," ").trim();
	}

/** 
 *
 * Remove duplicates from the finalList
 *
 */
	public void removeDuplicates() { 

        Set<String> set = new LinkedHashSet<String>();
        set.addAll(finalList); 
        finalList.clear(); 
        finalList.addAll(set); 
	}
	

/** 
 *
 * Remove duplicates from an arrayList
 *
 * @param input arrayList 
 * @return cleaned ArrayList
 */
	public static <T> ArrayList<T> removeDuplicates(ArrayList<T> arrayList) { 

        Set<T> set = new LinkedHashSet<T>();
        set.addAll(arrayList); 
        arrayList.clear(); 
        arrayList.addAll(set); 
        return arrayList;
	}

/** 
 *
 * Gets the atomic noun phrases
 *
 * @param nps  all noun phrases in the document
 */
	public void getAtomicNPs(Collection<NP> nps) { 

		ArrayList<NP> sentence= new ArrayList<NP>();
		ArrayList<NP> toRemove= new ArrayList<NP>();
		for(NP np: nps) {
			if(sentence.isEmpty()) {
				sentence.add(np);
				continue;
			}
			boolean match=false;
			for(NP s: sentence)
				if(s.getCoveredText().contains(np.getCoveredText())) {
					match=true;
					toRemove.add(s);
				}
			if(match) sentence.add(np);
			else {
				toRemove=removeDuplicates(toRemove);
				sentence.removeAll(toRemove);
				nounPhrases_cleaned.addAll(sentence);
				sentence.clear();
				toRemove.clear();
			}
		}
	}

/** 
 *
 * Save keywords to a file
 *
 * @param filename
 * @param toSave  the keywords list
 * @throws   FileNotFoundException 
 */
	public void saveKeywords(String filename,ArrayList<String> toSave) throws FileNotFoundException { 

		PrintWriter pw = new PrintWriter(new File(filename));
        for(String line: toSave)
        	pw.write(line+"\n");
        pw.close();
	}
}
