package lu.svv.saa.maana.proj;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;
import java.util.StringTokenizer;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.fit.component.JCasConsumer_ImplBase;
import org.apache.uima.jcas.JCas;
import de.tudarmstadt.ukp.dkpro.core.api.metadata.type.DocumentMetaData;
import de.tudarmstadt.ukp.wikipedia.api.Category;
import de.tudarmstadt.ukp.wikipedia.api.DatabaseConfiguration;
import de.tudarmstadt.ukp.wikipedia.api.Page;
import de.tudarmstadt.ukp.wikipedia.api.WikiConstants;
import de.tudarmstadt.ukp.wikipedia.api.Wikipedia;
import de.tudarmstadt.ukp.wikipedia.api.exception.WikiApiException;
import de.tudarmstadt.ukp.wikipedia.api.exception.WikiInitializationException;
import de.tudarmstadt.ukp.wikipedia.api.exception.WikiTitleParsingException;



 /**
 * The Wikipedia corpus creator class
 */ 
public class WikipediaCorpusCreator 
		extends JCasConsumer_ImplBase 
		implements WikiConstants {
	public static final String DRIVER_CLASS = "com.mysql.cj.jdbc.Driver"; 
	public static String mainDir = "./data/";
	public static ArrayList<String> Keywords = new ArrayList<String>();
	public static ArrayList<String> processedPages = new ArrayList<String> ();
	public static ArrayList<String> processedCats = new ArrayList<String> ();
	public static HashMap<String, Integer> Categories = new HashMap<String,Integer>();
	public static HashMap<Page, String[]> articles = new HashMap<Page,String[]>();
	public static double BNCsize=100000000;
	public static double alpha=0.5;
	public static int minCatLimit=250;
	

/** 
 *
 * Start: initialize variables
 *
 */
	public void start() { 

		
		 Keywords = new ArrayList<String>();
		 processedPages = new ArrayList<String> ();
		 processedCats = new ArrayList<String> ();
		 Categories = new HashMap<String,Integer>();
		 articles = new HashMap<Page,String[]>();
		 mainDir = "./data/";
	}
	
	@Override

/** 
 *
 * Process: main function
 * Connects with mysql database
 * (Don't forget to update the database credentials)
 * Use the extracted keywords to query wikipedia
 * 
 * @param aJCas  the a J cas
 * @throws   AnalysisEngineProcessException 
 */
	public void process(JCas aJCas) throws AnalysisEngineProcessException { 

		start();
		mainDir+=DocumentMetaData.get(aJCas).getDocumentTitle().split("\\.")[0]+"-"+Main.DSCParameters[0]+"-"+Main.DSCParameters[1]+"-"+Main.DSCParameters[2];
		if(createFolder(mainDir)==0) return;
		System.out.println("Starting . . . ");
		mainDir+="/";
		try {
			Class.forName(DRIVER_CLASS);
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		Keywords=Glossary.removeDuplicates(Main.keywords);
        // configure the database connection parameters
        DatabaseConfiguration dbConfig = new DatabaseConfiguration();
        dbConfig.setHost("localhost:3306");
        dbConfig.setDatabase("wikipedia");
        dbConfig.setUser("root");
        dbConfig.setPassword("rootroot");
        dbConfig.setLanguage(Language.english);
        
        Wikipedia wiki = null;
		try {
			wiki = new Wikipedia(dbConfig);
		} catch (WikiInitializationException e1) {
			e1.printStackTrace();
		}
        ArrayList<String> usedkeywords= new ArrayList<String>();
        
        int totalnbrwords=0;
        boolean iskeyword=false;
        
        for(String keyword: Keywords) {
        	Page page = null;
        	String pageText="";
        	for(String query: searchQueries(keyword)) {
        		try{
        			page= wiki.getPage(query);
        			if(processedPages.contains(page.getTitle().toString())) {
        				page=null;
        				continue;
        			}
        			pageText=page.getPlainText();
            		totalnbrwords+= (new StringTokenizer(pageText)).countTokens();
        		}catch (Exception e) {
        			//System.out.println("++ Query:" +query + " Not Found");
        			continue;
				}
        		if(!pageText.isEmpty()) {
        			String title = null;
					try {
						title = page.getTitle().toString();
					} catch (WikiTitleParsingException e) {
						e.printStackTrace();
					}
        			processedPages.add(title);
        			articles.put(page, new String[] {keyword,pageText});
        			break;
        		}
        	}
        }
        double catLimit= alpha*BNCsize/(1000*articles.size());
        if(catLimit<minCatLimit) catLimit=minCatLimit;
        for(Entry<Page,String[]> entry: articles.entrySet()) {
        	Page page =entry.getKey();
        	String keyword = entry.getValue()[0];
        	String pageText = entry.getValue()[1];
	    	if(pageText.isEmpty()) continue;
	    	usedkeywords.add(keyword);
	    	createFolder(mainDir+keyword);
        	save(pageText,keyword+"/main",keyword);
	    	cat:for(Category cat: page.getCategories()) {
	        	String catTitle = null;
				try {
					catTitle = cat.getTitle().toString();
				} catch (WikiTitleParsingException e) {
					e.printStackTrace();
				}
	        	if(Categories.containsKey(catTitle)) continue;
	    		int nbrPages = 0;
				try {
					nbrPages = cat.getNumberOfPages();
				} catch (WikiApiException e) {
					e.printStackTrace();
				}
	        	if (nbrPages>catLimit) {
	        		continue cat;
	        	}
        		Categories.put(catTitle, nbrPages);
        		int nbrwords = 0;
				try {
					nbrwords = categoryWordCount(wiki,cat,keyword,catTitle);
				} catch (WikiApiException e) {
					e.printStackTrace();
				}
        		totalnbrwords+= nbrwords;
        		if(iskeyword) {
        		}
	        }
        }
        save(String.join(", ", usedkeywords),"Keywords","kw");
        System.out.println("# words: "+totalnbrwords);
	}


/** 
 *
 * Gets articles from the given category
 *
 * @param wiki  the wikipedia object
 * @param cat  the category id
 * @return the category articles
 * @throws   WikiApiException 
 */
    public static Set<Page> getCatPages(Wikipedia wiki,long cat) throws WikiApiException { 

		return wiki.getCategory((int) cat).getArticles();
	}

/** 
 *
 * Gets the category articles in string format
 *
 * @param wiki  the wikipedia object
 * @param cat  the category id
 * @return the category articles as string
 * @throws   WikiApiException 
 */
	public static ArrayList<String> getCatPagesString(Wikipedia wiki,long cat) throws WikiApiException { 

		ArrayList<String> pages= new ArrayList<String>();
		for(Page p: getCatPages(wiki,cat)) {
			pages.add(p.getPlainText());
		}
		return pages;
	}

/** 
 *
 * Category word count: counts the number of words within a given category
 *
 * @param wiki  the wikipedia object
 * @param cat  the category object
 * @param keyword  the keyword leading to the category (used to save the set of article)
 * @param catTitle  the category title
 * @return int total count
 * @throws   WikiTitleParsingException
 * @throws  WikiApiException 
 */
	public static int categoryWordCount(Wikipedia wiki, Category cat, String keyword, String catTitle) throws WikiTitleParsingException, WikiApiException { 

		int wordCount=0;
		for(Page page: cat.getArticles())
			try {
				String pageText = page.getPlainText();
				wordCount += (new StringTokenizer(pageText)).countTokens();
				String dir=catTitle.replaceAll("[^a-zA-Z ]", "");
				save(pageText, keyword+"/"+dir, page.getTitle().toString());
			} catch (Exception e) {
				return 0;
			}
		return wordCount;
	}

/** 
 *
 * Save an article in a folder
 *
 * @param pageText  the article text
 * @param folder  the folder path
 * @param file  the filename
 */
	private static void save(String pageText, String folder, String file) { 

		createFolder(mainDir+folder.trim());
		try{
			PrintWriter out = new PrintWriter(mainDir+folder.trim()+"/"+file.replaceAll("[^a-zA-Z ]", "")+".txt");
		    out.println(pageText);
		    out.close();
		}catch (Exception e) {
			System.out.println("Couldn't write "+file);
		}
	}

/** 
 *
 * Create folder
 *
 * @param path 
 * @return int
 */
	public static int createFolder(String path) { 

		File f = new File(path);
		if (!f.exists()) {
		    if(f.mkdir()) { 
		        //System.out.println(folder+ " Directory Created");
		    } else {
		        System.out.println(path+ "= Directory is not created");
		    }
		    return 1;
		} else return 0; 
	}

/** 
 *
 * Read a string file from the given path
 *
 * @param the file path
 */
	public static void read(String filePath) { 

		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(filePath));
			String line = reader.readLine();
			while (line != null) {
				Keywords.add(line);
				line = reader.readLine();
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

/** 
 *
 * Generate Search queries from the input phrase
 *
 * @param phrase
 * @return ArrayList<String> searchQueries
 */
	public static ArrayList<String> searchQueries(String phrase) { 

		String [] words = phrase.split(" ");
		ArrayList<String> phrases = new ArrayList<String>();
		for (int i = 0; i < words.length-1; i++) {
			for (int j = i+2; j <= words.length; j++) 
				phrases.add(String.join(" ", Arrays.copyOfRange(words,i,j)));
		}
		Collections.sort(phrases, new Comparator<String>() {

            

/** 
 *
 * Compare
 *
 * @param o1  the o1
 * @param o2  the o2
 * @return int
 */
            public int compare(String o1, String o2) { 

                if(o1.length()>=o2.length()){
                    return -1;
                }else if(o1.length()<o2.length()){ 
                	return 1;
                } else {
                    return o1.compareTo(o2);
                }
            }
        });
		return phrases;
	}
	
}
