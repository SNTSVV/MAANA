package lu.svv.saa.maana.proj;


import static org.apache.uima.fit.util.JCasUtil.select;
import static org.apache.uima.fit.util.JCasUtil.selectCovered;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map.Entry;
import java.util.regex.Pattern;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.jcas.JCas;
import org.uimafit.component.JCasAnnotator_ImplBase;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.NGram;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Sentence;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token;
import lu.svv.saa.maana.type.AmbiguousPhrase;


 /**
 * The class  PP attachment finder: find PP-attachment phrases within the structure V * N * P * N (*:intermediate words)
 * extends J cas annotator_ impl base
 */ 
public class PPAttachmentFinder extends JCasAnnotator_ImplBase {

	
	public static int id=0;
	public static int count=0;
	  static ArrayList<String> toSave=new ArrayList<String>();
	  static ArrayList<String> ProcessedPhrases=new ArrayList<String>();
	  static Pattern p = Pattern.compile("[^a-z0-9 ]", Pattern.CASE_INSENSITIVE);

  @Override

/** 
 *
 * Process: starting function of the class
 * Loops over sentences
 *
 * @param jcas  the jcas
 * @throws   AnalysisEngineProcessException 
 */
  public void process(JCas jcas) throws AnalysisEngineProcessException { 


	  toSave=new ArrayList<String>();
	  count=0;
	  ProcessedPhrases=new ArrayList<String>();
	  for (Sentence sentence : select(jcas, Sentence.class)) {
		  patternIdentifier(sentence,jcas);
	  }
  }

/** 
 *
 * Pattern identifier: finding PP-attachment phrases in the given sentence
 *
 * @param sentence  the sentence
 * @param jcas  the jcas
 */
  public void patternIdentifier(Sentence sentence, JCas jcas){ 

		String Sentence= sentence.getCoveredText();
		if (selectCovered(NGram.class, sentence).size() <= 0) return;
		Entry<Boolean,int[]> e =analyzeSentence(sentence);
		if(e.getKey()) {
			for(int i=1;i<selectCovered(Token.class, sentence).size();i++) {
				Token token=selectCovered(Token.class, sentence).get(i);
				if(token.getPos().getPosValue().equalsIgnoreCase("IN")){
					int[] idx = checkLxPP(sentence,i,7);
					if(idx[0]==0 && idx[1]==0) continue;
					String phrase= getText(sentence,idx[0],idx[1]);
					if(Main.p.matcher(phrase).find()) continue;
					if(ProcessedPhrases.contains(phrase)) continue;
					if(Main.ppPhrases.containsValue(sentence)) //if(checkphrase(phrase,sentence)) continue;
						if(checkPhrase(phrase)) continue;
					if(token.getCoveredText().equalsIgnoreCase("of") && selectCovered(Token.class, sentence).get(i-1).getPosValue().toLowerCase().startsWith("n") && selectCovered(Token.class, sentence).get(i+1).getPosValue().toLowerCase().startsWith("n")) count++;
					AmbiguousPhrase AmbiguiousPP=new AmbiguousPhrase(jcas);
					AmbiguiousPP.setBegin(getToken(sentence, idx[0]).getBegin());
					AmbiguiousPP.setEnd(getToken(sentence, idx[1]).getEnd());
					AmbiguiousPP.setId(0);
					AmbiguiousPP.setCCid(i-idx[0]);
					AmbiguiousPP.setMid(idx[2]-idx[0]);
					AmbiguiousPP.setN2id(idx[1]-idx[0]);
					AmbiguiousPP.setPattern("N/A");
					AmbiguiousPP.setSentence(Sentence.replace(";",",").replace("\n"," "));
					AmbiguiousPP.setText(phrase);
					AmbiguiousPP.setHeuristics(-1);
					AmbiguiousPP.addToIndexes();
					Main.ppPhrases.put(AmbiguiousPP, sentence);
					Main.LocalPhrases.add(phrase);				
					ProcessedPhrases.add(phrase);
				}
			}
		}
	}

/** 
 *
 * Check if the input phrase was already processed or not
 *
 * @param phrase  the input phrase
 * @return boolean
 */
  public boolean checkPhrase(String phrase) { 

	  String Phrase=phrase.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
	  for(String p: Main.LocalPhrases) {
		  String P=p.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
		  if(Phrase.equals(P) || Phrase.contains(P) || P.contains(Phrase)) {
			  return true;
		  }
	  }
	  return false;
  }

/** 
 *
 * Check if the given sentence has lexical PP-attachment
 *
 * @param sentence  the input sentence
 * @param Pid  the preposition index
 * @param threshold  the max window threshold
 * @return int[] contains starting and ending index of the PP-attachment phrase if found
 */
  public static int[] checkLxPP(Sentence sentence,int Pid,int threshold) { 

	    boolean v=false;
	    boolean n1=false;
	    boolean n2=false;
	    int [] indexes = new int[3];
	  for(int i=1;i<=Pid;i++){
			Token tok=selectCovered(Token.class, sentence).get(i);
			if(checkPrep(tok) && v && n1) 
				break;
			if(tok.getPosValue().toLowerCase().startsWith("vb") && !n1 ) {
		    	indexes[0]=i;
		        v=true;
		      }
		      if(tok.getPosValue().toLowerCase().startsWith("n") && v && !n1 ) {
		        n1=true;
		      }
		      if(tok.getPosValue().toLowerCase().startsWith("n") && v ) {
		    	  indexes[2]=i;
			  }
		      if(tok.getPosValue().toLowerCase().startsWith("vb") && n1)
		    	  n1=false;
	  }
	  if( v && n1)
		  for(int i=Pid+1;i<selectCovered(Token.class, sentence).size();i++) {
			      if(selectCovered(Token.class, sentence).get(i).getPosValue().toLowerCase().startsWith("n")  && !n2) {
			    	indexes[1]=i;
			        n2=true;
			      }
		  }
	  if(indexes[1]-indexes[0]>threshold || !n2)
		  return new int[2];
	  return indexes;
  }

/** 
 *
 * Gets the token given its position in the input sentence
 *
 * @param sentence  the input sentence
 * @param i  the token index
 * @return the token
 */
  public static Token getToken(Sentence sentence, int i) { 

		Token T=null;
		 try {
			 T=selectCovered(Token.class, sentence).get(i);
		 } catch (Exception e) {}
		 return T;
	 }

/** 
 *
 * Gets sentence text given start and end index
 *
 * @param s  the sentence
 * @param begin  the beginning index
 * @param end  the ending index
 * @return the sentence text
 */
  public static String getText(Sentence s, int begin, int end) { 

	 	StringBuilder text= new StringBuilder();
  	for(int i=begin;i<=end;i++) 
  		text.append(selectCovered(Token.class, s).get(i).getCoveredText()+" ");
  	return text.toString();
  }
/** 
 *
 * Analyze sentence: look for a v+n1+pp+n2 sequence allowing any num of intermediate words
 *
 * @param sentence  the sentence
 * @return Entry<Boolean,int[]> 
 */
  private static Entry<Boolean,int[]> analyzeSentence(Sentence sentence) { 
    boolean v=false;
    boolean n1=false;
    boolean n2=false;
    boolean prep = false;
    int[] indexes= new int[2];
    
    for(int i=1;i<selectCovered(Token.class, sentence).size();i++) {

    	Token tok=selectCovered(Token.class, sentence).get(i);
    	if (p.matcher(tok.getCoveredText()).find()) continue;
    	if(Arrays.asList(",",".",";",":").contains(tok.getCoveredText())) break;
      if(tok.getPosValue().toLowerCase().startsWith("vb") && !v && !n1 && !prep && !n2) {
    	indexes[0]=i;
        v=true;
      }      
      if(tok.getPosValue().toLowerCase().startsWith("n") && v && !n1 && !prep && !n2) {
        n1=true;
      }
      if(checkPrep(tok) && v && n1 && !prep && !n2) {
        prep=true;
      }
      if(tok.getPosValue().toLowerCase().startsWith("n") && v && n1 && prep && !n2) {
    	  if(indexes[1]!=0)
    		  indexes[1]=i;
          n2=true;
          break;
      }
    }
    return new AbstractMap.SimpleEntry<Boolean,int[]>(prep&&v&&n1&&n2,indexes);
  }

/** 
 *
 * Check if the input token is a preposition
 *
 * @param tok  the input token
 * @return boolean
 */
  public static boolean checkPrep(Token tok) { 

	  if(tok.getPosValue().equalsIgnoreCase("in") && !p.matcher(tok.getCoveredText()).find() && !tok.getCoveredText().equalsIgnoreCase("of")) {
		       return true;
	      }
	  return false;
  }
}
