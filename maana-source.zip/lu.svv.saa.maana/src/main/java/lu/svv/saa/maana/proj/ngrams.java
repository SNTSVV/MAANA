package lu.svv.saa.maana.proj;


import static org.apache.uima.fit.factory.CollectionReaderFactory.createReaderDescription;
import static org.uimafit.factory.AnalysisEngineFactory.createPrimitiveDescription;

import java.io.File;
import java.io.IOException;

import org.apache.uima.UIMAException;
import org.apache.uima.analysis_engine.AnalysisEngineDescription;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.collection.CollectionReaderDescription;
import org.apache.uima.fit.component.JCasConsumer_ImplBase;
import org.apache.uima.fit.pipeline.SimplePipeline;
import org.apache.uima.jcas.JCas;

import com.googlecode.jweb1t.JWeb1TIndexer;

import de.tudarmstadt.ukp.dkpro.core.api.metadata.type.DocumentMetaData;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token;
import de.tudarmstadt.ukp.dkpro.core.frequency.Web1TFileAccessProvider;
import de.tudarmstadt.ukp.dkpro.core.io.text.TextReader;
import de.tudarmstadt.ukp.dkpro.core.io.web1t.Web1TWriter;
import de.tudarmstadt.ukp.dkpro.core.tokit.BreakIteratorSegmenter;


 /**
 * The class Ngrams: creates ngrams from a text corpus or a collection of documents 
 * 
 * extends J cas consumer_ impl base
 */ 
public class ngrams extends JCasConsumer_ImplBase{
	private final static int MIN_NGRAM = 1;
	private final static int MAX_NGRAM = 5;
	private static String OUTPUT_PATH = "target/";
	public static String wikipath = "./data/";
	static Web1TFileAccessProvider web1tProvider=null;
		

/** 
 *
 * set path variables
 *
 */
	public void start() { 

		OUTPUT_PATH = "target/";	
		wikipath = "./data/";
		web1tProvider=null;
	}
	
    @Override

/** 
 *
 * Process: main function
 *
 * @param aJCas  the a J cas
 * @throws   AnalysisEngineProcessException 
 */
	public void process(JCas aJCas) throws AnalysisEngineProcessException { 

    	start();
    	OUTPUT_PATH+=DocumentMetaData.get(aJCas).getDocumentTitle().split("\\.")[0]+"-"+Main.DSCParameters[0]+"-"+Main.DSCParameters[1]+"-"+Main.DSCParameters[2];
    	if(createFolder(OUTPUT_PATH)==0) return;
    	wikipath+=DocumentMetaData.get(aJCas).getDocumentTitle().split("\\.")[0]+"-"+Main.DSCParameters[0]+"-"+Main.DSCParameters[1]+"-"+Main.DSCParameters[2];
    	try {
			web1twriter(OUTPUT_PATH,wikipath, new String[] { Token.class.getName() });
		} catch (UIMAException | IOException e) {
			e.printStackTrace();
		}
    }

/** 
 *
 * Web1twriter: ngrams corpus writer
 *
 * @param outputPath  the output path
 * @param wikipath  the wikipedia documents path 
 * @param classnames: the class names
 * @throws   UIMAException
 * @throws  IOException 
 */
	    public static void web1twriter(String outputPath, String wikipath, String[] classnames) throws UIMAException, IOException { 

	    	CollectionReaderDescription reader = createReaderDescription(TextReader.class,
					TextReader.PARAM_SOURCE_LOCATION, wikipath+"/**/*", TextReader.PARAM_PATTERNS, "",
					TextReader.PARAM_LANGUAGE, "en");
	 
	        AnalysisEngineDescription segmenter = createPrimitiveDescription(
	            BreakIteratorSegmenter.class);
	 
	        AnalysisEngineDescription ngramWriter = createPrimitiveDescription(
	            Web1TWriter.class,
	            Web1TWriter.PARAM_TARGET_LOCATION,  outputPath,
	            Web1TWriter.PARAM_INPUT_TYPES, classnames,
	            Web1TWriter.PARAM_MIN_NGRAM_LENGTH, MIN_NGRAM,
	            Web1TWriter.PARAM_MAX_NGRAM_LENGTH, MAX_NGRAM,
	            Web1TWriter.PARAM_MIN_FREQUENCY, 2);
	        
	        SimplePipeline.runPipeline(reader, segmenter, ngramWriter);
	
	        // create the necessary indexes
	        JWeb1TIndexer indexCreator = new JWeb1TIndexer("target/web1t/", 3);
	        indexCreator.create();
	    }		

/** 
 *
 * Create a folder in the given path
 *
 * @param path 
 * @return int returns 0 if the file path doesn't exist
 */
	    public static int createFolder(String path) { 

			File f = new File(path);
			if (!f.exists()) {
			    if(f.mkdir()) { 
			        //System.out.println(folder+ " Directory Created");
			    } else {
			        System.out.println(path.split("/")[path.split("/").length-1]+ "= Directory is not created");
			    }
			} else return 0; 
			return 1;	
		}
}
