package lu.svv.saa.maana.proj;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;


 /**
 * The Utils class
 */ 
public class utils {
	public static boolean readHeuristics=false;
	public static boolean saveHeuristics=false;

/** 
 *
 * Save PAA frequencies
 *
 * @param output folder 
 * @throws   IOException 
 */
	public static void saveFrequenciesPAA(String folder) throws IOException { 

		SaveFile(folder+"/XPFreq.hm",DomainSpecificHeuristicsPAA.XPFreq);
		SaveFile(folder+"/TFreqP.hm",DomainSpecificHeuristicsPAA.TFreq);
		SaveFile(folder+"/SFreqP.hm",DomainSpecificHeuristicsPAA.SFreq);
		SaveFile(folder+"/XPNFreq.hm",DomainSpecificHeuristicsPAA.XPNFreq); 
	}

/** 
 *
 * Read frequencies PAA
 *
 * @param input folder
 * @throws   IOException
 * @throws  ClassNotFoundException 
 */
	public static void readFrequenciesPAA(String folder) throws IOException, ClassNotFoundException { 

		DomainSpecificHeuristicsPAA.TFreq=LoadFile(folder+"/TFreqP.hm");
		DomainSpecificHeuristicsPAA.SFreq=LoadFile(folder+"/SFreqP.hm");
		DomainSpecificHeuristicsPAA.XPFreq=LoadFile(folder+"/XPFreq.hm");
		DomainSpecificHeuristicsPAA.XPNFreq=LoadFile(folder+"/XPNFreq.hm");
	}

/** 
 *
 * Save frequencies CA
 *
 * @param folder output
 * @throws   IOException 
 */
	public static void saveFrequenciesCA(String folder) throws IOException { 

		SaveFile(folder+"/TFreq.hm",DomainSpecificHeuristicsCA.TFreq);
		SaveFile(folder+"/SFreq.hm",DomainSpecificHeuristicsCA.SFreq);
		SaveFile(folder+"/PPFrequency.hm",DomainSpecificHeuristicsCA.PPFrequency);
		SaveFile(folder+"/Freq.hm",DomainSpecificHeuristicsCA.Freq);
		SaveFile(folder+"/VtoVFreq.hm",DomainSpecificHeuristicsCA.VtoVFreq);
		SaveFile(folder+"/CCFreq.hm",DomainSpecificHeuristicsCA.CCFreq);
		SaveFile(folder+"/SSMap.hm",DomainSpecificHeuristicsCA.SSMap);
		SaveFile(folder+"/DSMap.hm",DomainSpecificHeuristicsCA.DSMap); 
	}

/** 
 *
 * Read frequencies CA
 *
 * @param folder input
 * @throws   IOException
 * @throws  ClassNotFoundException 
 */
	public static void readFrequenciesCA(String folder) throws IOException, ClassNotFoundException { 

		DomainSpecificHeuristicsCA.TFreq=LoadFile(folder+"/TFreq.hm");
		DomainSpecificHeuristicsCA.SFreq=LoadFile(folder+"/SFreq.hm");
		DomainSpecificHeuristicsCA.PPFrequency=LoadFile(folder+"/PPFrequency.hm");
		DomainSpecificHeuristicsCA.Freq=LoadFile(folder+"/Freq.hm");
		DomainSpecificHeuristicsCA.VtoVFreq=LoadFile(folder+"/VtoVFreq.hm");
		DomainSpecificHeuristicsCA.CCFreq=LoadFile(folder+"/CCFreq.hm");
		DomainSpecificHeuristicsCA.SSMap=LoadFile(folder+"/SSMap.hm");
		DomainSpecificHeuristicsCA.DSMap=LoadFile(folder+"/DSMap.hm");
	}

/** 
 *
 * Save object to a file
 *
 * @param output Path
 * @param ps  object to save
 * @throws   IOException
 */
	public static <V> void SaveFile(String Path, V ps) throws IOException{	 

		FileOutputStream fos = new FileOutputStream(Path);
		GZIPOutputStream gz = new GZIPOutputStream(fos);
		ObjectOutputStream oos = new ObjectOutputStream(gz);
		oos.writeObject(ps);
		oos.close();
		fos.close();
	}

/** 
 *
 * Load object from a file
 *
 * @param input Path
 * @return loaded object
 * @throws   FileNotFoundException
 * @throws  IOException
 * @throws  ClassNotFoundException
 */
	public static <V> V LoadFile(String Path) throws FileNotFoundException, IOException, ClassNotFoundException{ 

		FileInputStream fin = new FileInputStream(Path);
		GZIPInputStream gis = new GZIPInputStream(fin);
		ObjectInputStream ois = new ObjectInputStream(gis);
		@SuppressWarnings("unchecked")
		V Mp = (V) ois.readObject();
		ois.close();
		return Mp;
	}
}
