package lu.svv.saa.maana.proj;


import static org.apache.uima.fit.util.JCasUtil.selectCovered;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.fit.component.JCasConsumer_ImplBase;
import org.apache.uima.fit.util.JCasUtil;
import org.apache.uima.jcas.JCas;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Sentence;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token;
import lu.svv.saa.maana.type.AmbiguousPhrase;


 /**
 * The CA pattern finder class
 *  
 * extends J cas consumer_ impl base
 */ 
public class CAPattern extends JCasConsumer_ImplBase {
	private static boolean useExtendedPatterns = Main.useExtendedPatterns;
	static ArrayList<String> localphrases=new ArrayList<String>();
	static ArrayList<String> localsentences=new ArrayList<String>();
	static int id=0;
	static ArrayList<String> toSave=new ArrayList<String>();
	@Override

/** 
 *
 * Process: main function
 * 
 * loops over sentences for patterns identification
 *
 * @param aJCas the a J cas
 * @throws   AnalysisEngineProcessException 
 */
	public void process(JCas aJCas) throws AnalysisEngineProcessException { 

		Main.ccPhrases = new HashMap<AmbiguousPhrase,Sentence>();
		Main.nbrOfSentences+=JCasUtil.select(aJCas, Sentence.class).size();
		toSave=new ArrayList<String>();
		localphrases=new ArrayList<String>();
		for (Sentence sentence : JCasUtil.select(aJCas, Sentence.class)) {
			patternIdentifier(sentence,aJCas);				
	    }
		Main.AmbiguousPhrases.addAll(localphrases);
		Main.AmbiguousSentences.addAll(localsentences);
	}
	public static String[] Patterns= {"",
			"nn n c n",
			"n c n nn",
			"nn p n c n",
			"n c n p nn",
			"n c n vb",
			"adj nn n c n",
			"nn n c n nn",
			"vb n c n",
			"adj n c n",
			"adj adj n c n ",
			"vb to v c v",
			"v c v to vb",
			"adv v c v",
			"nn p v c v",
			"v c v p nn",
			"v c v nn",
			"v c v adv",
			"adv adj c adj",
			"adj c adj adv",
			"N/A",
//			"n c n p dt/adj nn",
			"dt/adj nn p v c v",
			"N/A",
//			"v c v p dt/adj nn",
			"adj cc adj adj nn",
			"nn adj nn cc adj nn",
			"dt n c dt n vb",
			"nn p dt n c dt n",
			"dt n c dt n nn",
			"vb dt n c dt n",
			"dt n c dt n p dt/adj nn",
			"nn dt n c dt n nn",
			"dt n c dt n p nn",
			"adj dt n c dt n",
			"nn dt n c dt n",
			"adj nn dt n c dt n",
			"nn p dt/adj n c n"
			};
	public static int[] CCiDs= {0,2,1,3,1,1,3,2,2,2,3,3,1,2,3,1,1,1,2,1,1,4,1,1,3,2,4,2,3,2,3,2,3,3,4,4};
	public static int[] modifierIds= {-1,0,3,0,4,3,1,0,0,0,1,0,4,0,0,4,3,3,0,3,5,1,5,4,0,5,0,5,0,7,0,6,0,0,1,0};

/** 
 *
 * Pattern identifier
 *
 * @param sentence 
 * @param jcas  the jcas
 */
	public static void patternIdentifier(Sentence sentence, JCas jcas){ 

		char conjunctsType=0;
		int[] coordinationType= {0,0,0,0,0};
		int f=0;
		int inter=0;
		List<String> phrases = new ArrayList<String>();
		for(int i=1;i<selectCovered(Token.class, sentence).size();i++) {
			Token token=selectCovered(Token.class, sentence).get(i);
			if(CheckCC(token)){
				conjunctsType=CheckConjuncts(sentence,i);
				if (conjunctsType==0 && useExtendedPatterns) {
					conjunctsType=CheckInterConjuncts(sentence,i);
					inter=1;
				}
				if (conjunctsType==0)
					continue;
				if(inter==0) coordinationType=checkPattern(sentence,i,conjunctsType);
				else coordinationType=checkInterPattern(sentence,i,conjunctsType);
				if(coordinationType[0]==0 || coordinationType.length==0 || coordinationType[0]<0 )
					continue;
				AmbiguousPhrase AmbiguiousCA=new AmbiguousPhrase(jcas);
				AmbiguiousCA.setBegin(coordinationType[1]);
				AmbiguiousCA.setEnd(coordinationType[2]);
				AmbiguiousCA.setId(coordinationType[0]);
				AmbiguiousCA.setCCid(CCiDs[coordinationType[0]]);
				AmbiguiousCA.setMid(modifierIds[coordinationType[0]]);
				AmbiguiousCA.setPattern(Patterns[coordinationType[0]]);
				AmbiguiousCA.setSentence(sentence.getCoveredText().replace(";",",").replace("\n"," "));
				AmbiguiousCA.setText(getText(sentence,coordinationType[3],coordinationType[4]));
				AmbiguiousCA.addToIndexes();
				Main.ccPhrases.put(AmbiguiousCA, sentence);
				phrases.add(getText(sentence,coordinationType[3],coordinationType[4]));
				Main.LocalPhrases.add(getText(sentence,coordinationType[3],coordinationType[4]));
				if(!localphrases.contains(AmbiguiousCA.getCoveredText())) {
					localphrases.add(AmbiguiousCA.getCoveredText());
				}
				if(!localsentences.contains(AmbiguiousCA.getSentence()))
					localsentences.add(AmbiguiousCA.getSentence());

				Main.nbrOfCOOPhrases++;
				f=1;
			}
		}
		if(f==1) {
			Main.nbrOfCoordinations++;
		}
	}

/** 
 *
 * Check if token is a conjuction
 *
 * @param token
 * @return boolean
 */
	public static boolean CheckCC(Token t) { 

		String[] al = {"and","or","&","'n","et","nor"};
		for(String s: al) {
			if(t.getCoveredText().equalsIgnoreCase(s))
				return true;
		}
		return false;
	}

/** 
 *
 * Check headwords POSTags
 *
 * @param sentence
 * @param CCid  the  Conjunction id
 * @return char POSTag 
 */
	public static char CheckConjuncts(Sentence sentence, int CCid) { 

		char[] listPOS= {'n','v','j'}; // Noun, Verb, Adverb
		for(char pos : listPOS)
			if(getPos(sentence,CCid+1).charAt(0)==pos && getPos(sentence,CCid-1).charAt(0)==pos)
				return pos;
		return 0;
	}

/** 
 *
 * Check inter conjuncts POSTags
 *
 * @param sentence
 * @param CCid  the Conjunction id
 * @return char
 */
	public static char CheckInterConjuncts(Sentence sentence, int CCid) { 

		if(getPos(sentence,CCid-2).charAt(0)=='d' && getPos(sentence,CCid-1).charAt(0)=='n' && getPos(sentence,CCid+1).charAt(0)=='d' && getPos(sentence,CCid+2).charAt(0)=='n')
			return 'd';
		if(getPos(sentence,CCid-2).charAt(0)=='j' && getPos(sentence,CCid-1).charAt(0)=='n' && getPos(sentence,CCid+1).charAt(0)=='j' && getPos(sentence,CCid+2).charAt(0)=='n')
			return 'j';
		return 0;
	}

/** 
 *
 * Check pattern
 *
 * @param sentence
 * @param CCid the Conjunction id
 * @param ConjunctsType the conjuncts type
 * @return int[] pattern id
 */
	public static int[] checkPattern(Sentence sentence,int CCid, char ConjunctsType) { 

			switch(ConjunctsType) {
			case 'n':
				if(getPos(sentence,CCid+2).startsWith("n")) {
					if(getPos(sentence,CCid-2).startsWith("n")) {
						return ccList(7,sentence,CCid-2,CCid+2);//nn n c n nn
						}
					else return ccList(2,sentence,CCid-1,CCid+2); //n c n nn
					}
				if(getPos(sentence,CCid-2).startsWith("n")) {
					if(getPos(sentence,CCid-3).startsWith("j"))
						return ccList(6,sentence,CCid-3,CCid+1); //adj nn n c n
					else return ccList(1,sentence,CCid-2,CCid+1); //nn n c n
					}			
				if(getPos(sentence,CCid-2).startsWith("i")) 
					if(getPos(sentence,CCid-3).startsWith("n"))
						return ccList(3,sentence,CCid-3,CCid+1); //nn p n c n
				if(getPos(sentence,CCid+2).startsWith("i")) 
					if(getPos(sentence,CCid+3).startsWith("d") || getPos(sentence,CCid+3).startsWith("j")) {
						if(getPos(sentence,CCid+4).startsWith("n")) 
						return ccList(20,sentence,CCid-1,CCid+4); //n c n p dt/adj nn
					} else if(getPos(sentence,CCid+3).startsWith("n")) 
						return ccList(4,sentence,CCid-1,CCid+3); //n c n p nn
				if(getPos(sentence,CCid-2).startsWith("d") || getPos(sentence,CCid-2).startsWith("j")) {
					if(getPos(sentence,CCid-3).startsWith("i"))
						if(getPos(sentence,CCid-4).startsWith("n"))
							return ccList(35,sentence,CCid-4,CCid+1); //nn p dt/adj n c n
				}
				if(getPos(sentence,CCid+2).startsWith("v"))
					return ccList(5,sentence,CCid-1,CCid+2); //n c n vb
				if(getPos(sentence,CCid-2).startsWith("v"))
					return ccList(8,sentence,CCid-2,CCid+1); //vb n c n
				if(getPos(sentence,CCid-2).startsWith("j")) {
					if(getPos(sentence,CCid-3).startsWith("j"))
						return ccList(10,sentence,CCid-3,CCid+1); //adj adj n c n
					else return ccList(9,sentence,CCid-2,CCid+1); //adj n c n
					}
			case 'v':
				if(getPos(sentence,CCid-2).startsWith("t")) 
					if(getPos(sentence,CCid-3).startsWith("v"))
						return ccList(11,sentence,CCid-3,CCid+1); //vb to v c v
				if(getPos(sentence,CCid+2).startsWith("t")) 
					if(getPos(sentence,CCid+3).startsWith("v"))
						return ccList(12,sentence,CCid-1,CCid+3); //v c v to vb
				if(getPos(sentence,CCid-2).startsWith("r"))
					return ccList(13,sentence,CCid-2,CCid+1); //adv v c v	
				if(getPos(sentence,CCid-2).startsWith("i")) {
					if(getPos(sentence,CCid-3).startsWith("n"))
						if(getPos(sentence,CCid-4).startsWith("d") || getPos(sentence,CCid-4).startsWith("j")) {
							return ccList(21,sentence,CCid-4,CCid+1); //dt/adj nn p v c v
						} 
					return ccList(14,sentence,CCid-3,CCid+1); //nn p v c v
					}
				if(getPos(sentence,CCid+2).startsWith("i")) 
					if(getPos(sentence,CCid+3).startsWith("d") || getPos(sentence,CCid+3).startsWith("j")) {
						if(getPos(sentence,CCid+4).startsWith("n")) 
						return ccList(22,sentence,CCid-1,CCid+4); //v c v p dt/adj nn
					} else if(getPos(sentence,CCid+3).startsWith("n")) 
						return ccList(15,sentence,CCid-1,CCid+3); //v c v p nn
				if(getPos(sentence,CCid+2).startsWith("n"))
					return ccList(16,sentence,CCid-1,CCid+2); //v c v nn
				if(getPos(sentence,CCid+2).startsWith("r"))
					return ccList(17,sentence,CCid-1,CCid+2); //v c v adv
			case 'j':
				if(getPos(sentence,CCid-2).startsWith("r"))
					return ccList(18,sentence,CCid-2,CCid+1); //adv adj c adj	
				if(getPos(sentence,CCid+2).startsWith("r"))
					return ccList(19,sentence,CCid-1,CCid+2); //adj c adj adv
				if(getPos(sentence,CCid+2).startsWith("j") && getPos(sentence,CCid+3).startsWith("n"))
					return ccList(23,sentence,CCid-1,CCid+3); //adj cc adj adj nn
		}
		return new int[] {0,0,0};
	}

/** 
 *
 * Check inter pattern
 *
 * @param sentence
 * @param CCid  the Conjunction id
 * @param ConjunctsType  the conjuncts type (POSTag)
 * @return int[] pattern id
 */
	public static int[] checkInterPattern(Sentence sentence,int CCid, char ConjunctsType) { 

		switch(ConjunctsType) {
		case 'd':
			if(getPos(sentence,CCid+3).startsWith("v"))
				return ccList(25,sentence,CCid-2,CCid+3);//dt n c dt n vb
			if(getPos(sentence,CCid+3).startsWith("n"))
				return ccList(27,sentence,CCid-2,CCid+3);//dt n c dt n nn
			if(getPos(sentence,CCid-3).startsWith("v"))
				return ccList(28,sentence,CCid-3,CCid+2);//vb dt n c dt n
			if(getPos(sentence,CCid-2).startsWith("i")) 
				if(getPos(sentence,CCid-3).startsWith("n"))
					return ccList(26,sentence,CCid-3,CCid+2); //nn p dt n c dt n
			if(getPos(sentence,CCid+3).startsWith("i")) 
				if(getPos(sentence,CCid+4).startsWith("d") || getPos(sentence,CCid+4).startsWith("j")) {
					if(getPos(sentence,CCid+5).startsWith("n")) 
						return ccList(29,sentence,CCid-2,CCid+5); //dt n c dt n p dt/adj nn
				} else if(getPos(sentence,CCid+4).startsWith("n")) 
					return ccList(31,sentence,CCid-2,CCid+4); //dt n c dt n p nn
			if(getPos(sentence,CCid+3).startsWith("n") && getPos(sentence,CCid-3).startsWith("n"))
				return ccList(30,sentence,CCid-3,CCid+3); //nn dt n c dt n nn
			if(getPos(sentence,CCid-3).startsWith("j"))
				return ccList(32,sentence,CCid-3,CCid+2); //adj dt n c dt n
			if(getPos(sentence,CCid-3).startsWith("n")) {
				if(getPos(sentence,CCid-4).startsWith("j"))
					return ccList(34,sentence,CCid-4,CCid+2); //adj nn dt n c dt n
				else return ccList(33,sentence,CCid-3,CCid+2); //nn dt n c dt n
				}
		case 'j':
			if(getPos(sentence,CCid-3).startsWith("n"))
				return ccList(24,sentence,CCid-3,CCid+2); //nn adj nn cc adj nn	
	}
	return checkPattern(sentence,CCid,ConjunctsType);
}

/** 
 *
 * CA phrase indexes
 *
 * @param ambiguityID  the ambiguity identifier
 * @param sentence 
 * @param begin index
 * @param end  index
 * @return int[] indexes
 */
	public static int[] ccList(int ambiguityID,Sentence sentence,int begin, int end) { 

		int[] list=new int[]{-9,-9,-9};
		try {
			list=new int[]{ambiguityID,getToken(sentence,begin).getBegin(),getToken(sentence,end).getEnd(),begin,end};	
			return list;
		} catch (Exception e) {}
		return list;
	} 

/** 
 *
 * Gets the POSTag of token in a sentence
 *
 * @param sentence 
 * @param CCid  the token id
 * @return the POSTag
 */
	public static String getPos(Sentence sentence, int CCid) { 

		String POS="-1";
		 try {
			 POS=selectCovered(Token.class, sentence).get(CCid).getPosValue().toLowerCase();
		 } catch (Exception e) {}
		 return POS;
	 }

/** 
 *
 * Gets the token object
 *
 * @param sentence
 * @param CCid  the token id
 * @return the token object
 */
	public static Token getToken(Sentence sentence, int CCid) { 

		Token T=null;
		 try {
			 T=selectCovered(Token.class, sentence).get(CCid);
		 } catch (Exception e) {}
		 return T;
	 }

/** 
 *
 * Gets the segment text
 *
 * @param s  the sentence
 * @param begin index
 * @param end index
 * @return the text
 */
	 public static String getText(Sentence s, int begin, int end) { 

		 	StringBuilder text= new StringBuilder();
	    	for(int i=begin;i<=end;i++) 
	    		text.append(selectCovered(Token.class, s).get(i).getCoveredText()+" ");
	    	return text.toString();
	    }

/** 
 *
 * Gets the text POSTag
 *
 * @param Start index
 * @param End index
 * @param aJCas  the a J cas
 * @return the text POSTag
 */
	public static String getTextPOS(int Start, int End, JCas aJCas) { 

		StringBuilder text= new StringBuilder();
		for(Token t: selectCovered(aJCas,Token.class, Start, End))
			text.append(t.getCoveredText()+"("+t.getPosValue()+") ");
		return text.toString();
	}
}
