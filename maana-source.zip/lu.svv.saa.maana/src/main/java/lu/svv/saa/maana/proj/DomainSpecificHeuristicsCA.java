package lu.svv.saa.maana.proj;


import static org.apache.uima.fit.util.JCasUtil.selectCovered;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.lang3.StringUtils;
import org.apache.uima.UIMAException;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.fit.util.JCasUtil;
import org.apache.uima.jcas.JCas;
import org.uimafit.component.JCasConsumer_ImplBase;
import de.tudarmstadt.ukp.dkpro.core.api.metadata.type.DocumentMetaData;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Sentence;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token;
import de.tudarmstadt.ukp.dkpro.core.api.syntax.type.constituent.ROOT;
import de.tudarmstadt.ukp.dkpro.core.frequency.Web1TFileAccessProvider;
import de.tudarmstadt.ukp.dkpro.core.io.penntree.PennTreeUtils;
import edu.cmu.lti.lexical_db.NictWordNet;
import edu.cmu.lti.ws4j.RelatednessCalculator;
import edu.cmu.lti.ws4j.impl.Resnik;
import edu.cmu.lti.ws4j.util.WS4JConfiguration;
import lu.svv.saa.maana.type.AmbiguousPhrase;


 /**
 * The class: Domain specific heuristics calculation for CA 
 *  
 * extends J cas consumer_ impl base
 */ 
public class DomainSpecificHeuristicsCA extends JCasConsumer_ImplBase{
	static boolean UseWeightedVotes=Main.UseWeightedVotes;
	static boolean UseBNC=Main.UseBNC;
	static boolean UseOptimalThresholds=Main.UseOptimalThresholds;
	static boolean UseParser=false;
	static boolean UsedParser=false;
	private static double tCM = 0.0;
	private static double tDS = 0.0;
	private static double tSS = 0.0;
	private static double tMO = 0.0;
		private final static int MIN_NGRAM = 1;
		private final static int MAX_NGRAM = 5;
		private static final double w1 = 0.012453812331507441;
		private static final double w2 = 0.019097537503312445;
		private static final double w3 = 0.0025992772731739944;
		private static final double w4 = 0.004840894846793953;
		private static final double w5 = 0.037601366163415806;
		private static final double w6 = 0.00478824992938498;
		
		private static String INPUT_PATH = "corpus/";
		static Web1TFileAccessProvider web1tProvider=null;
		static ArrayList<String> ngrams=new ArrayList<String>();
		public static double[] decisionsThresholds= Main.decisionsThresholds;
		private static int[] Hdecisions= {0,0,0};
		private static ArrayList<int[]> heuristics= new ArrayList<int[]>();
		public static int id=0;
		public static ArrayList<String> CAtoSave=new ArrayList<String>();
		
		public static ArrayList<String> sentencesToSave=new ArrayList<String>();
		static int nbrOfQueries=0;		
		private static NictWordNet db = new NictWordNet();
		private static RelatednessCalculator SimilarityCalculator=new Resnik(db);
		static HashMap<String,HashMap<String,Long>> PPFrequency= new HashMap<String,HashMap<String,Long>>();
		static HashMap<String,HashMap<String,Long>> Freq= new HashMap<String,HashMap<String,Long>>();
		static HashMap<String,Long> TFreq= new HashMap<String,Long>();
		static HashMap<String,Long> SFreq= new HashMap<String,Long>();
		static HashMap<String,HashMap<String,Long>> VtoVFreq= new HashMap<String,HashMap<String,Long>>();
		static HashMap<String,HashMap<String,Long>> CCFreq= new HashMap<String,HashMap<String,Long>>();
		static HashMap<String,HashMap<String,Double>> SSMap= new HashMap<String,HashMap<String,Double>>();
		static HashMap<String,HashMap<String,Float>> DSMap= new HashMap<String,HashMap<String,Float>>();
		static Map<String,Integer> filelist = new HashMap<String,Integer>(){
			private static final long serialVersionUID = 4580800093158014820L;
		{
			put("Pac",1);
	    	put("EAR",2);put("GST",2);put("GDD",2);put("EDR",2);
	    	put("Ros",3);
	    	put("IEE",4);put("Non",4);put("RQM",4);
	    	put("Web",5);put("Ele",5);put("Kno",5);
	    	put("Lun",6);put("Cou",6);put("ECH",6);put("Fin",6);
	    	put("Evi",7);put("Kee",7);
	    	put("Dat",8);put("Hal",8);
	    }};
		static ArrayList<String> Stop_Words = getStopWords(readfile(Main.stopWordsPath));
		static long startTime;

		
		

/** 
 *
 * Process: the main function of the class
 *
 * @param aJCas  the a J cas object
 * @throws   AnalysisEngineProcessException 
 */
		public void process(JCas aJCas) throws AnalysisEngineProcessException { 

			System.out.println(DocumentMetaData.get(aJCas).getDocumentTitle());
			if(UseBNC) {
				INPUT_PATH= "corpus/BNC";
			} else 
				INPUT_PATH= Main.corpusValue;
			if(UseOptimalThresholds) {
				tCM = 0.01;
				tDS = 0.12;
				tSS = 3.45;
				tMO = 3.0;
			} else {
				tCM = 0.01;
				tDS = 0.01;
				tSS = 0.0;
				tMO = 1.0;
			}
			CAtoSave=new ArrayList<String>();
			try {
				prepareCorpus();
			} catch (IOException e) {
				System.out.println("Failed to prepare the corpus");
				e.printStackTrace();
				return;
			}
			if(utils.readHeuristics) {
				try {
					utils.readFrequenciesCA(INPUT_PATH+"/1gms");
				} catch (ClassNotFoundException e1) {
					e1.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			System.out.println("Calculating CA heuristics ");
			for(AmbiguousPhrase AmbiguiousPhrase: JCasUtil.select(aJCas, AmbiguousPhrase.class)) {
				try {
					String phrase=AmbiguiousPhrase.getText();
					if(!Main.LocalPhrases.contains(phrase)) continue;
					if(!Main.processedPhrases.contains(phrase)){

						idRead(AmbiguiousPhrase);
						Main.processedPhrases.add(phrase);
						System.out.print(".");
					}
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
			if(utils.saveHeuristics) {
				try {
					utils.saveFrequenciesCA("Freqs");
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			try {
				if(Main.choiceValue==1) {
					Main.toSave=CAtoSave;
				} else {
					DocumentMetaData dmd = DocumentMetaData.get(aJCas);
					save2CSV(Main.outputDir+dmd.getDocumentTitle().split("\\.")[0]+"-CA.csv", CAtoSave);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}


/** 
 *
 * Prepare the domain specific corpus
 *
 * @param IOException  the  IO exception
 * @throws   IOException 
 */
		private void prepareCorpus() throws IOException { 
			WS4JConfiguration.getInstance().setMFS(true);
			if(!utils.readHeuristics) {
				web1tProvider = prepareWeb1TFormat();
				ngrams=getNgrams(5);
			}
		}

/** 
 *
 * read identification using heuristics
 *
 * @param phrase
 * @throws   NullPointerException
 * @throws  HttpException
 * @throws  IOException
 * @throws  InterruptedException
 * @throws  UIMAException 
 */
		public static void idRead(AmbiguousPhrase phrase) throws NullPointerException, HttpException, IOException, InterruptedException, UIMAException { 

			int ccId=phrase.getCCid();
			int patternId=phrase.getId();
			int modifierId=phrase.getMid();
			int[] decisions= {0,0,0,0,0,0,0};
			Token headword1;
			Token headword2;
			int headword2Id=1;
			if(patternId>23 && patternId!=35) headword2Id=2;
			Token modifier=selectCovered(Token.class, phrase).get(modifierId);
			if(modifierId<ccId) {
				headword1=selectCovered(Token.class, phrase).get(ccId-1);
				headword2=selectCovered(Token.class, phrase).get(ccId+headword2Id);
			} else {
				headword1=selectCovered(Token.class, phrase).get(ccId+headword2Id);
				headword2=selectCovered(Token.class, phrase).get(ccId-1);			
			}
			if(ccId==-1 || ccId+ 1==selectCovered(Token.class, phrase).size() || ccId==0) return;
			float CM = CoordinationMatch(headword1.getCoveredText(),headword2.getCoveredText());
			float DS = DistributionalSimilarity(headword1,headword2);
			float[] CF=CollocationFrequency(headword1,headword2,modifier,ccId,phrase);
			int Morph=Morphology(headword1, headword2);

			double SS= SemanticSimilarity(headword1, headword2);
			int PD= -1;
			int flag=0;
			if(CM>tCM){
				decisions[0]=1;
				flag+=1;
				}
			if(DS>tDS)
				{decisions[1]=1;
				flag+=2;}
			if(CF[0]>0)//CF[1]-CF[2]>tCF)
				{decisions[2]=2;
				flag+=4;}
			if(Morph>tMO) {
				decisions[3]=1;
				flag+=8;
			}
			if(SS>tSS) {
				decisions[4]=1;
				flag+=16;
			}
			if(UseParser) {
				PD= ParserDecision(Main.ccPhrases.get(phrase),selectCovered(Token.class, phrase).get(ccId-1).getCoveredText());
				decisions[5]=PD;
				UsedParser=true;
				if(PD==1) flag+=32;
				else if(PD==2) flag+=64;
				else if(PD==-1) UsedParser=false;
			}
			if(UseWeightedVotes) {
				decisions[6]=weightVotes(decisions[0],decisions[2],decisions[1],decisions[4],decisions[3],decisions[5]); 
				}
			else {
				if(UsedParser) {
					if(Arrays.asList(7,13,14,21,22,28,37,37,44,52,65,66,72,79,80,87,93,94).contains(flag)) {
						Hdecisions[0]++;
						decisions[6]=0;
						}
					else if(Arrays.asList(5,6,12,20,36,64,68,69,70,71,76,77,78,84,85,86,92,100).contains(flag)) {Hdecisions[2]++;
						decisions[6]=2;
							}
					else {Hdecisions[1]++; 
					decisions[6]=1;
					}
				} else {
					if(Arrays.asList(0,5,6,12,39,45,53,46,54,60,20,33,34,40,48).contains(flag)) {
						Hdecisions[0]++;
						decisions[6]=0;
						}
					else if(Arrays.asList(4,32,36,37,38,44,52).contains(flag)) {Hdecisions[2]++;
						decisions[6]=2;
						}
					else {
						Hdecisions[1]++; 
						decisions[6]=1;
					}
				}
			}
			heuristics.add(decisions);
			toSave2(phrase.getSentence().replace(";",",").replace("\n"," "), phrase.getText(), "CA", decisions[6],phrase.getPattern());
		}

/** 
 *
 * Weighted vote
 *
 * @param H1  the h1
 * @param H2  the h2
 * @param H3  the h3
 * @param H4  the h4
 * @param H5  the h5
 * @param H6  the h6
 * @return int
 */
		public static int weightVotes(int H1,int H2, int H3, int H4, int H5, int H6) { 

			double FRScore,SRScore;
			FRScore=H1*w1+H3*w3+H4*w4+H5*w5+(H6==1 ? H6*w6 : 0);
			SRScore=(H2==2 ? w2 : 0) + (H6==2 ? w6 : 0);
			if(FRScore>SRScore) return 1;
			else if(FRScore<SRScore) return 2;
			else return 0;
		}
		

/** 
 *
 * Morphology heuristic
 *
 * @param headword1  the first head word
 * @param headword2  the second head word
 * @return int decision
 */
		public static int Morphology(Token headword1, Token headword2) { 

			String word1=headword1.getCoveredText().toLowerCase();
			String word2=headword2.getCoveredText().toLowerCase();
			int maxLenth=Math.min(word1.length(), word2.length());
			int output=0;
			for(int i=1;i<=maxLenth;i++) {
				if(word1.substring(word1.length() - i).equals(word2.substring(word2.length() - i))) {
					output=i;
				} else return output;
			}
			return output;
		}

/** 
 *
 * Parser heuristic
 *
 * @param sentence
 * @param wordBeforeCC  the word before the conjunction
 * @return int decision
 */
		private static int ParserDecision(Sentence sentence,String wordBeforeCC) { 

			String pennTree="";
			for(ROOT root : selectCovered(ROOT.class, sentence)) {
				pennTree= PennTreeUtils.toPennTree(PennTreeUtils.convertPennTree(root));
			}
	    	String[] elements=pennTree.split(" ");
	    	int id=-1;
	    	for (int i=0; i<elements.length;i++)
				if(elements[i].equals("(CC") && elements[i-1].startsWith(wordBeforeCC)) {
					id=i;
					break;
				}
	    	if(id==-1) return -1;
	    	if((!elements[id-1].endsWith("))") || (elements[id-1].endsWith("))") && elements[id-3].startsWith("("))) 
	    			&& (!elements[id+3].startsWith("("))||(elements[id+3].startsWith("(") && elements[id+4].endsWith("))"))) return 1;
	    	if((elements[id-1].endsWith("))") && !elements[id-3].startsWith("("))
	    			||(elements[id+3].startsWith("(") && !elements[id+4].endsWith("))"))) return 2;
	    	
		   return 0;
		 }

/** 
 *
 * Collocation heuristic
 *
 * @param headword1  the first head word
 * @param headword2  the second head word
 * @param modifier  the modifier
 * @param ccId  the conjunction index
 * @param phrase
 * @return float[] decision and frequencies
 * @throws   IOException
 * @throws  NullPointerException
 * @throws  InterruptedException 
 */
	    public static float[] CollocationFrequency(Token headword1, Token headword2, Token modifier, int ccId, AmbiguousPhrase phrase) throws IOException, NullPointerException, InterruptedException { 

	    	int freqmh1=(int) getFreq(headword1.getCoveredText(),modifier.getCoveredText());
	    	int freqh1= (int) getFreq(headword1);
	    	int freqmh2=(int) getFreq(headword2.getCoveredText(),modifier.getCoveredText());
	    	int freqh2= (int) getFreq(headword2);
	    	float freq1=0;
	    	if(freqh1!=0){freq1= freqmh1/freqh1;}
	    	float freq2=0;
	    	if(freqh2!=0){freq2= freqmh2/freqh2;}
	    	int patternId=phrase.getId();
	    	int modifierId=phrase.getMid();
			if(!Arrays.asList(3,4,11,12,14,15,20,21,22).contains(patternId)){
		    	if(modifierId<ccId) {
		    			if(freq1>freq2) return new float[] {2,freq1,freq2};
		    	}
				else if(freq1<freq2) return new float[] {2,freq2,freq1};
			}else if(patternId==11) return CFFreqArray(VtoVFreq(modifier,headword1),VtoVFreq(modifier,headword2),freqh1,freqh2);
			 else if(patternId==12) return CFFreqArray(VtoVFreq(headword1,modifier),VtoVFreq(headword2,modifier),freqh1,freqh2);
			 else {
				if(modifierId<ccId) return CFFreqArray(PPFrequency(modifier,selectCovered(Token.class, phrase).get(ccId-2),headword1),PPFrequency(modifier,selectCovered(Token.class, phrase).get(ccId-2),headword2),freqh1,freqh2);
				else return CFFreqArray(PPFrequency(headword1,selectCovered(Token.class, phrase).get(ccId+2),modifier),PPFrequency(headword2,selectCovered(Token.class, phrase).get(ccId+2),modifier),freqh1,freqh2);
				}
			return new float[] {0,freq1,freq2};
	    }

/** 
 *
 * Distributional similarity heuristic between two tokens
 *
 * @param token1
 * @param token2
 * @return Float similarity value
 * @throws   IOException
 * @throws  UIMAException 
 */
	    public static Float DistributionalSimilarity(Token token1, Token token2) throws IOException, UIMAException { 

	    	String word1=token1.getCoveredText();
	    	String word2=token2.getCoveredText();
			String word1Stem=token1.getStemValue();
			String word2Stem=token2.getStemValue();
			String word1Lemma=token1.getLemmaValue();
			String word2Lemma=token2.getLemmaValue();
			if(utils.readHeuristics) {
				if(DSMap.containsKey(word1))
		    		if(DSMap.get(word1).containsKey(word2))
		    			return DSMap.get(word1).get(word2);
		    	if(DSMap.containsKey(word2))
		    		if(DSMap.containsKey(word1))
		    			return DSMap.get(word2).get(word1);				
			}
			nbrOfQueries++;
	    	Set<String> word1Context=new HashSet<String>();
	    	Set<String> word2Context=new HashSet<String>();
	    	Iterator<String> itr =ngrams.iterator();
	    	while(itr.hasNext()) {
	    		String ngram=removeStopWords(itr.next());
	    		if(Arrays.asList(new String[] {word1,word1Lemma==null ? "N/A": word1Lemma,word1Stem==null ? "N/A":word1Stem}).stream().anyMatch(ngram::contains)) 
	    			word1Context.addAll(new HashSet<String>(Arrays.asList(StringUtils.split(ngram))));
	    		if(Arrays.asList(new String[] {word2,word2Lemma==null ? "N/A": word2Lemma,word2Stem==null ? "N/A":word2Stem}).stream().anyMatch(ngram::contains)) 
	    			word2Context.addAll(new HashSet<String>(Arrays.asList(StringUtils.split(ngram))));
	    	}
	    	Set<String> intersection = new HashSet<String>(word1Context); 
	    	if (intersection.isEmpty()) return (float) 0;
	    	intersection.retainAll(word2Context);
	    	Float measure = (float) intersection.size() / (word1Context.size()+word2Context.size());
	    	if(utils.saveHeuristics) {
		    	HashMap<String,Float> hm = new HashMap<String,Float>();
		    	if(DSMap.containsKey(word1)) {
		    		hm=DSMap.get(word1);
		    		hm.put(word2, measure);
		    		DSMap.put(word1, hm);
		    		return measure;
		    	}
		    	if(DSMap.containsKey(word2)) {
		    		hm=DSMap.get(word2);
		    		hm.put(word1, measure);
		    		DSMap.put(word2, hm);
		    		return measure;
		    	}	    	
		    	hm.put(word2, measure);
		    	DSMap.put(word1, hm);
	    	}
			return measure;
	    }

/** 
 *
 * Coordination match heuristic between two words
 *
 * @param word1
 * @param word2
 * @return float
 * @throws   IOException 
 */
		public static float CoordinationMatch(String word1, String word2) throws IOException { 
			long freq1=  getSavedFreq(word1, SFreq);
			long freq2=  getSavedFreq(word2, SFreq);
			if(freq1<0)
				freq1 = web1tProvider.getFrequency(word1);
			if(freq2<0)
				freq2 = web1tProvider.getFrequency(word2);
			if(utils.saveHeuristics) {
				SFreq.put(word1, freq1);
				SFreq.put(word2, freq2);
			}
			long freq12 = getCCFreq(word1,word2);
			if((freq1+freq2-freq12)==0) return 0;
	    	return (float) freq12/(freq1+freq2-freq12);
	    }

/** 
 *
 * Semantic similarity heuristic of two headwords
 *
 * @param headword1  
 * @param headword2  
 * @return double similarity value
 */
		public static double SemanticSimilarity(Token headword1, Token headword2) { 

			String word1=headword1.getCoveredText();
			String word2=headword2.getCoveredText();
			if(utils.readHeuristics) {
				if(SSMap.containsKey(word1))
		    		if(SSMap.get(word1).containsKey(word2))
		    			return SSMap.get(word1).get(word2);
		    	if(SSMap.containsKey(word2))
		    		if(SSMap.containsKey(word1))
		    			return SSMap.get(word2).get(word1);
			}
			
			double SS1=SemanticSimilarity(headword1.getLemmaValue().toLowerCase(),headword2.getLemmaValue().toLowerCase());	
	
			nbrOfQueries++;
			if(utils.saveHeuristics) {
				HashMap<String,Double> hm = new HashMap<String,Double>();
		    	if(SSMap.containsKey(word1)) {
		    		hm=SSMap.get(word1);
		    		hm.put(word2, SS1);
		    		SSMap.put(word1, hm);
		    		return SS1;
		    	}
		    	if(SSMap.containsKey(word2)) {
		    		hm=SSMap.get(word2);
		    		hm.put(word1, SS1);
		    		SSMap.put(word2, hm);
		    		return SS1;
		    	}	    	
		    	hm.put(word2, SS1);
		    	SSMap.put(word1, hm);
			}
			return SS1;
		}

/** 
 *
 * Semantic similarity of word1 and word2
 *
 * @param word1
 * @param word2 
 * @return double similarity value
 */
		public static double SemanticSimilarity(String word1, String word2) { 

			return SimilarityCalculator.calcRelatednessOfWords(word1, word2);
		}

/** 
 *
 * Remove stop words from a given string
 *
 * @param input  the input string
 * @return String without stop words
 */
		public static String removeStopWords(String input) { 

			ArrayList<String> words= new ArrayList<String>();
			for(String word: input.split(" "))
				if(!Stop_Words.contains(word))
					words.add(word);
			return String.join(" ", words);
		}

/** 
 *
 * Prepare web1 T format to open a corpus
 *
 * @param IOException{  the  IO exception{
 * @return Web1TFileAccessProvider
 * @throws   IOException
 */
		private static Web1TFileAccessProvider prepareWeb1TFormat() throws IOException{ 

	            Web1TFileAccessProvider web1tProvider = new Web1TFileAccessProvider("en", new File(INPUT_PATH),
	                    MIN_NGRAM, MAX_NGRAM);
	            return web1tProvider;
	    }

/** 
 *
 * Gets the ngrams from the corpus
 *
 * @param n  the n parameter
 * @return the ngrams
 * @throws   IOException 
 */
	    public static ArrayList<String> getNgrams(int n) throws IOException { 

	    	ArrayList<String> ngrams= new ArrayList<String>(); 
	    	Iterator<String> itr =web1tProvider.getNgramIterator(n);
	    	while(itr.hasNext())
	    		ngrams.add(itr.next());
	    	return ngrams;
	    }

/** 
 *
 * Gets the saved frequency of two words from the frequency map
 *
 * @param word1
 * @param word2  
 * @param FreqMap  the frequency map
 * @return the saved frequency
 */
	    public static long getSavedFreq(String word1, String word2, HashMap<String,HashMap<String,Long>> FreqMap) { 

	    	if(!utils.readHeuristics) return -1;
			if(FreqMap.containsKey(word1))
	    		if(FreqMap.get(word1).containsKey(word2))
	    			return FreqMap.get(word1).get(word2);
	    	if(FreqMap.containsKey(word2))
	    		if(FreqMap.containsKey(word1))
	    			return FreqMap.get(word2).get(word1);
	    	return 0;
	    }
	    
/** 
*
* Gets the saved frequency of a given token from the frequency map
*
* @param word token
* @param FreqMap  the frequency map
* @return the saved frequency
*/
	    public static long getSavedFreq(Token word, HashMap<Token,Long> FreqMap) { 
	    	if(!utils.readHeuristics) return -1;
			if(FreqMap.containsKey(word))
    			return FreqMap.get(word);
	    	return -1;
	    }
/** 
*
* Gets the saved frequency of a given token from the frequency map
*
* @param word token
* @param FreqMap  the frequency map
* @return the saved frequency
*/
	    public static long getSavedFreq(String word, HashMap<String,Long> FreqMap) { 
	    	if(!utils.readHeuristics) return -1;
			if(FreqMap.containsKey(word))
    			return FreqMap.get(word);
	    	return 0;
	    }
/** 
 *
 * Gets the coordination frequency of two words
 *
 * @param word1 
 * @param word2 
 * @return the  coordination frequency
 * @throws   IOException 
 */
	    public static long getCCFreq(String word1, String word2) throws IOException { 

	    	long freq = 0;
	    	if(utils.readHeuristics) {
		    	freq=getSavedFreq(word1, word2, CCFreq);
		    	if(freq>=0) return freq;
	    	}
	    	freq=web1tProvider.getFrequency(word1+" and "+word2)
	    			+web1tProvider.getFrequency(word1+" or "+word2)
	    			+web1tProvider.getFrequency(word1+" & "+word2)
	    			+web1tProvider.getFrequency(word2+" and "+word1)
	    			+web1tProvider.getFrequency(word2+" & "+word1)
	    			+web1tProvider.getFrequency(word2+" or "+word1);
	    	nbrOfQueries+=6;
	    	if(utils.saveHeuristics) {
		    	HashMap<String,Long> hm = new HashMap<String,Long>();
		    	if(CCFreq.containsKey(word1)) {
		    		hm=CCFreq.get(word1);
		    		hm.put(word2, freq);
		    		CCFreq.put(word1, hm);
		    		return freq;
		    	}
		    	if(CCFreq.containsKey(word2)) {
		    		hm=CCFreq.get(word2);
		    		hm.put(word1, freq);
		    		CCFreq.put(word2, hm);
		    		return freq;
		    	}	    	
		    	hm.put(word2, freq);
		    	CCFreq.put(word1, hm);
		    }
	    	return freq;
	    }

/** 
 *
 * Gets the frequency of a given token
 *
 * @param word  the token
 * @return the frequency
 * @throws   IOException 
 */
	    public static long getFreq(Token token) throws IOException {
	    	String word = token.getCoveredText();
	    	long freq=getSavedFreq(word, TFreq);
	    	if(freq>=0) return freq;
	    	freq=web1tProvider.getFrequency(word);
	    	if(!token.getLemmaValue().equals(word))
	    		freq+=web1tProvider.getFrequency(token.getLemmaValue());
	    	if(utils.saveHeuristics) {
	    		TFreq.put(word, freq);
	    	}
	    	return freq;
	    }

/** 
 *
 * Gets the collocation frequency of two words
 *
 * @param word1  
 * @param word2  
 * @return the frequency
 * @throws   IOException 
 */
	    public static long getFreq(String word1, String word2) throws IOException { 

	    	long freq=getSavedFreq(word1, word2, Freq);
	    	if(freq>=0) return freq;
	    	freq =web1tProvider.getFrequency(word1+" "+word2)+web1tProvider.getFrequency(word2+" "+word1);
	    	nbrOfQueries++;
	    	if(utils.saveHeuristics) {
		    	HashMap<String,Long> hm = new HashMap<String,Long>();
		    	if(Freq.containsKey(word1)) {
		    		hm=Freq.get(word1);
		    		hm.put(word2, freq);
		    		Freq.put(word1, hm);
		    		return freq;
		    	}
		    	if(Freq.containsKey(word2)) {
		    		hm=Freq.get(word2);
		    		hm.put(word1, freq);
		    		Freq.put(word2, hm);
		    		return freq;
		    	}	    	
		    	hm.put(word2, freq);
		    	Freq.put(word1, hm);
	    	}
	    	return freq;
	    }

/** 
 *
 * Verb to Verb format frequency 
 *
 * @param headword (verb)  
 * @param modifier (verb)
 * @return int: frequency
 * @throws   NullPointerException
 * @throws  HttpException
 * @throws  IOException
 * @throws  InterruptedException 
 */
		public static int VtoVFreq(Token headword, Token modifier) throws NullPointerException, HttpException, IOException, InterruptedException { 

			String word1=headword.getCoveredText();
			String word2=modifier.getCoveredText();
	    	long freq=  getSavedFreq(word1, word2, VtoVFreq);
	    	if(freq>=0) return (int) freq;
	    	freq =web1tProvider.getFrequency(word1+" to "+word2);
	    	nbrOfQueries++;
	    	if(utils.saveHeuristics) {
		    	HashMap<String,Long> hm = new HashMap<String,Long>();
		    	if(VtoVFreq.containsKey(word1)) {
		    		hm=VtoVFreq.get(word1);
		    		hm.put(word2, freq);
		    		VtoVFreq.put(word1, hm);
		    		return (int)freq;
		    	}
		    	if(VtoVFreq.containsKey(word2)) {
		    		hm=VtoVFreq.get(word2);
		    		hm.put(word1, freq);
		    		VtoVFreq.put(word2, hm);
		    		return (int)freq;
		    	}	    	
		    	hm.put(word2, freq);
		    	VtoVFreq.put(word1, hm);
	    	}
	    	return (int)freq;
		}

/** 
 *
 *  Prepositional phrase format frequency
 *
 * @param headword
 * @param p  the preposition
 * @param modifier
 * @return int: frequency
 * @throws   NullPointerException
 * @throws  HttpException
 * @throws  IOException
 * @throws  InterruptedException 
 */
		public static int PPFrequency(Token headword, Token p, Token modifier) throws NullPointerException, HttpException, IOException, InterruptedException { 

			String word1=headword.getCoveredText();
			String word2=p.getCoveredText()+" "+modifier.getCoveredText();
			long freq=  getSavedFreq(word1, word2, PPFrequency);
	    	if(freq>=0) return (int) freq;
	    	freq=web1tProvider.getFrequency(headword.getCoveredText()+" "+p.getCoveredText()+" "+modifier.getCoveredText());
	    	nbrOfQueries++;
	    	if(utils.saveHeuristics) {
		    	HashMap<String,Long> hm = new HashMap<String,Long>();
		    	if(PPFrequency.containsKey(word1)) {
		    		hm=PPFrequency.get(word1);
		    		hm.put(word2, freq);
		    		PPFrequency.put(word1, hm);
		    		return (int)freq;
		    	}
		    	if(PPFrequency.containsKey(word2)) {
		    		hm=PPFrequency.get(word2);
		    		hm.put(word1, freq);
		    		PPFrequency.put(word2, hm);
		    		return (int)freq;
		    	}	    	
		    	hm.put(word2, freq);
		    	PPFrequency.put(word1, hm);
	    	}
			return (int) freq;
		}

/** 
 *
 *  Collocation frequency array for special cases
 *
 * @param freqmh1  frequency of modifier+headword1
 * @param freqmh2  frequency of modifier+headword2
 * @param freqh1  frequency of headword1
 * @param freqh2  frequency of headword2
 * @return float[] normalized frequency
 */
		public static float[] CFFreqArray(int freqmh1, int freqmh2, int freqh1, int freqh2) { 

			float freq1=0;
	    	if(freqh1!=0)
	    		freq1= freqmh1/freqh1;
	    	float freq2=0;
	    	if(freqh2!=0) 
	    		freq2= freqmh2/freqh2;
			if(freq1>freq2) return new float[] {2,freq1,freq2};
			else  return new float[] {0,freq1,freq2};
		}

/** 
 *
 * Read file from url
 *
 * @param url  
 * @return String
 */
		public static String readfile(String url){ 

			File fileDir = new File(url);
			String texte="";
			try {
				BufferedReader bf = new BufferedReader(new InputStreamReader( new FileInputStream(fileDir), "utf-8"));
				String input = bf.readLine();
				while(input!=null){
					texte = texte.concat(input);
					input = bf.readLine();
				}
				bf.close();
				return texte;
			} catch(Exception ex){System.out.println(ex.toString());}
			return texte;
		}

/** 
 *
 * Extracts the stop words from the stopwords file
 *
 * @param Words  the stopwords file
 * @return the stop words
 */
		public static ArrayList<String> getStopWords(String Words){ 

			StringTokenizer Stop_Words = new StringTokenizer(Words, ", ");
			ArrayList<String> Stop_Words2 = new ArrayList<String>();
			while(Stop_Words.hasMoreTokens()){
				Stop_Words2.add(Stop_Words.nextToken());
			}
			return Stop_Words2;
		}

/** 
 *
 * To save: preparing to output lines to save
 *
 * @param sentence  
 * @param phrase  
 * @param ambiguity_type
 * @param FD:  the Final Decision
 * @param pattern 
 */
		public static void toSave2(String sentence, String phrase, String ambiguity_type, int FD,String pattern) { 

			StringBuilder sb = new StringBuilder();
	        sb.append(sentence);
	        sb.append(';');
	        int index=0;
	        index=sentence.indexOf(phrase);
	        if (index<1)
	        	index=sentence.indexOf(phrase.split(" ")[0]);
	        if(Main.useOffsets)
	        	sb.append(index);
	        else
	        	sb.append(phrase);
	        sb.append(';');
	        sb.append("CA");
	        sb.append(';');
	        if(pattern.contains("N/A"))
	        	{
		        if(FD==1)
	        		sb.append("1-First Read");
	        	else if(FD==2)
	        		sb.append("2-Second Read");
	        	else
	        		sb.append("0-Ambiguous");
	        	}
	        else 
	        	sb.append("0-Ambiguous");
	        if(Main.detailedOutput)
	        	sb.append(" -p "+pattern+" -h "+FD+ " -f "+phrase);
	        sb.append('\n');
	        if(!sentencesToSave.contains(sentence))
	        	sentencesToSave.add(sentence);
	    	CAtoSave.add(sb.toString());
	        id++;
		}

/** 
 *
 * Save to CSV: create a csv file with the header then loops of over the prepared toSave list 
 *
 * @param filename
 * @param toSave  the toSave list
 * @throws   FileNotFoundException 
 */
		public static void save2CSV(String filename,ArrayList<String> toSave) throws FileNotFoundException { 

			PrintWriter pw = new PrintWriter(new File(filename));
	        StringBuilder sb = new StringBuilder();
	        sb.append("Sentence");
	        sb.append(';');
	        sb.append("Beginning offset");
	        sb.append(';');
	        sb.append("Ambiguity Type");
	        sb.append(';');
	        sb.append("Final Decision");
	        sb.append('\n');
	        pw.write(sb.toString());
	        for(String line: toSave)
	        	pw.write(line);
	        pw.close();
	        System.out.println(filename+" created!");
		}
}
