
/* First created by JCasGen Thu Jan 21 17:12:36 CET 2021 */
package lu.svv.saa.maana.type;

import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.cas.impl.TypeImpl;
import org.apache.uima.cas.Type;
import org.apache.uima.cas.impl.FeatureImpl;
import org.apache.uima.cas.Feature;
import org.apache.uima.jcas.tcas.Annotation_Type;

/** 
 * Updated by JCasGen Thu Jan 21 17:12:38 CET 2021
 * @generated */
public class AmbiguousPhrase_Type extends Annotation_Type {
  /** @generated */
  @SuppressWarnings ("hiding")
  public final static int typeIndexID = AmbiguousPhrase.typeIndexID;
  /** @generated 
     @modifiable */
  @SuppressWarnings ("hiding")
  public final static boolean featOkTst = JCasRegistry.getFeatOkTst("lu.svv.saa.maana.type.AmbiguousPhrase");
 
  /** @generated */
  final Feature casFeat_id;
  /** @generated */
  final int     casFeatCode_id;
  /** @generated
   * @param addr low level Feature Structure reference
   * @return the feature value 
   */ 
  public int getId(int addr) {
        if (featOkTst && casFeat_id == null)
      jcas.throwFeatMissing("id", "lu.svv.saa.maana.type.AmbiguousPhrase");
    return ll_cas.ll_getIntValue(addr, casFeatCode_id);
  }
  /** @generated
   * @param addr low level Feature Structure reference
   * @param v value to set 
   */    
  public void setId(int addr, int v) {
        if (featOkTst && casFeat_id == null)
      jcas.throwFeatMissing("id", "lu.svv.saa.maana.type.AmbiguousPhrase");
    ll_cas.ll_setIntValue(addr, casFeatCode_id, v);}
    
  
 
  /** @generated */
  final Feature casFeat_CCid;
  /** @generated */
  final int     casFeatCode_CCid;
  /** @generated
   * @param addr low level Feature Structure reference
   * @return the feature value 
   */ 
  public int getCCid(int addr) {
        if (featOkTst && casFeat_CCid == null)
      jcas.throwFeatMissing("CCid", "lu.svv.saa.maana.type.AmbiguousPhrase");
    return ll_cas.ll_getIntValue(addr, casFeatCode_CCid);
  }
  /** @generated
   * @param addr low level Feature Structure reference
   * @param v value to set 
   */    
  public void setCCid(int addr, int v) {
        if (featOkTst && casFeat_CCid == null)
      jcas.throwFeatMissing("CCid", "lu.svv.saa.maana.type.AmbiguousPhrase");
    ll_cas.ll_setIntValue(addr, casFeatCode_CCid, v);}
    
  
 
  /** @generated */
  final Feature casFeat_Mid;
  /** @generated */
  final int     casFeatCode_Mid;
  /** @generated
   * @param addr low level Feature Structure reference
   * @return the feature value 
   */ 
  public int getMid(int addr) {
        if (featOkTst && casFeat_Mid == null)
      jcas.throwFeatMissing("Mid", "lu.svv.saa.maana.type.AmbiguousPhrase");
    return ll_cas.ll_getIntValue(addr, casFeatCode_Mid);
  }
  /** @generated
   * @param addr low level Feature Structure reference
   * @param v value to set 
   */    
  public void setMid(int addr, int v) {
        if (featOkTst && casFeat_Mid == null)
      jcas.throwFeatMissing("Mid", "lu.svv.saa.maana.type.AmbiguousPhrase");
    ll_cas.ll_setIntValue(addr, casFeatCode_Mid, v);}
    
  
 
  /** @generated */
  final Feature casFeat_N2id;
  /** @generated */
  final int     casFeatCode_N2id;
  /** @generated
   * @param addr low level Feature Structure reference
   * @return the feature value 
   */ 
  public int getN2id(int addr) {
        if (featOkTst && casFeat_N2id == null)
      jcas.throwFeatMissing("N2id", "lu.svv.saa.maana.type.AmbiguousPhrase");
    return ll_cas.ll_getIntValue(addr, casFeatCode_N2id);
  }
  /** @generated
   * @param addr low level Feature Structure reference
   * @param v value to set 
   */    
  public void setN2id(int addr, int v) {
        if (featOkTst && casFeat_N2id == null)
      jcas.throwFeatMissing("N2id", "lu.svv.saa.maana.type.AmbiguousPhrase");
    ll_cas.ll_setIntValue(addr, casFeatCode_N2id, v);}
    
  
 
  /** @generated */
  final Feature casFeat_text;
  /** @generated */
  final int     casFeatCode_text;
  /** @generated
   * @param addr low level Feature Structure reference
   * @return the feature value 
   */ 
  public String getText(int addr) {
        if (featOkTst && casFeat_text == null)
      jcas.throwFeatMissing("text", "lu.svv.saa.maana.type.AmbiguousPhrase");
    return ll_cas.ll_getStringValue(addr, casFeatCode_text);
  }
  /** @generated
   * @param addr low level Feature Structure reference
   * @param v value to set 
   */    
  public void setText(int addr, String v) {
        if (featOkTst && casFeat_text == null)
      jcas.throwFeatMissing("text", "lu.svv.saa.maana.type.AmbiguousPhrase");
    ll_cas.ll_setStringValue(addr, casFeatCode_text, v);}
    
  
 
  /** @generated */
  final Feature casFeat_sentence;
  /** @generated */
  final int     casFeatCode_sentence;
  /** @generated
   * @param addr low level Feature Structure reference
   * @return the feature value 
   */ 
  public String getSentence(int addr) {
        if (featOkTst && casFeat_sentence == null)
      jcas.throwFeatMissing("sentence", "lu.svv.saa.maana.type.AmbiguousPhrase");
    return ll_cas.ll_getStringValue(addr, casFeatCode_sentence);
  }
  /** @generated
   * @param addr low level Feature Structure reference
   * @param v value to set 
   */    
  public void setSentence(int addr, String v) {
        if (featOkTst && casFeat_sentence == null)
      jcas.throwFeatMissing("sentence", "lu.svv.saa.maana.type.AmbiguousPhrase");
    ll_cas.ll_setStringValue(addr, casFeatCode_sentence, v);}
    
  
 
  /** @generated */
  final Feature casFeat_pattern;
  /** @generated */
  final int     casFeatCode_pattern;
  /** @generated
   * @param addr low level Feature Structure reference
   * @return the feature value 
   */ 
  public String getPattern(int addr) {
        if (featOkTst && casFeat_pattern == null)
      jcas.throwFeatMissing("pattern", "lu.svv.saa.maana.type.AmbiguousPhrase");
    return ll_cas.ll_getStringValue(addr, casFeatCode_pattern);
  }
  /** @generated
   * @param addr low level Feature Structure reference
   * @param v value to set 
   */    
  public void setPattern(int addr, String v) {
        if (featOkTst && casFeat_pattern == null)
      jcas.throwFeatMissing("pattern", "lu.svv.saa.maana.type.AmbiguousPhrase");
    ll_cas.ll_setStringValue(addr, casFeatCode_pattern, v);}
    
  
 
  /** @generated */
  final Feature casFeat_textBegin;
  /** @generated */
  final int     casFeatCode_textBegin;
  /** @generated
   * @param addr low level Feature Structure reference
   * @return the feature value 
   */ 
  public int getTextBegin(int addr) {
        if (featOkTst && casFeat_textBegin == null)
      jcas.throwFeatMissing("textBegin", "lu.svv.saa.maana.type.AmbiguousPhrase");
    return ll_cas.ll_getIntValue(addr, casFeatCode_textBegin);
  }
  /** @generated
   * @param addr low level Feature Structure reference
   * @param v value to set 
   */    
  public void setTextBegin(int addr, int v) {
        if (featOkTst && casFeat_textBegin == null)
      jcas.throwFeatMissing("textBegin", "lu.svv.saa.maana.type.AmbiguousPhrase");
    ll_cas.ll_setIntValue(addr, casFeatCode_textBegin, v);}
    
  
 
  /** @generated */
  final Feature casFeat_textEnd;
  /** @generated */
  final int     casFeatCode_textEnd;
  /** @generated
   * @param addr low level Feature Structure reference
   * @return the feature value 
   */ 
  public int getTextEnd(int addr) {
        if (featOkTst && casFeat_textEnd == null)
      jcas.throwFeatMissing("textEnd", "lu.svv.saa.maana.type.AmbiguousPhrase");
    return ll_cas.ll_getIntValue(addr, casFeatCode_textEnd);
  }
  /** @generated
   * @param addr low level Feature Structure reference
   * @param v value to set 
   */    
  public void setTextEnd(int addr, int v) {
        if (featOkTst && casFeat_textEnd == null)
      jcas.throwFeatMissing("textEnd", "lu.svv.saa.maana.type.AmbiguousPhrase");
    ll_cas.ll_setIntValue(addr, casFeatCode_textEnd, v);}
    
  
 
  /** @generated */
  final Feature casFeat_heuristics;
  /** @generated */
  final int     casFeatCode_heuristics;
  /** @generated
   * @param addr low level Feature Structure reference
   * @return the feature value 
   */ 
  public int getHeuristics(int addr) {
        if (featOkTst && casFeat_heuristics == null)
      jcas.throwFeatMissing("heuristics", "lu.svv.saa.maana.type.AmbiguousPhrase");
    return ll_cas.ll_getIntValue(addr, casFeatCode_heuristics);
  }
  /** @generated
   * @param addr low level Feature Structure reference
   * @param v value to set 
   */    
  public void setHeuristics(int addr, int v) {
        if (featOkTst && casFeat_heuristics == null)
      jcas.throwFeatMissing("heuristics", "lu.svv.saa.maana.type.AmbiguousPhrase");
    ll_cas.ll_setIntValue(addr, casFeatCode_heuristics, v);}
    
  



  /** initialize variables to correspond with Cas Type and Features
	 * @generated
	 * @param jcas JCas
	 * @param casType Type 
	 */
  public AmbiguousPhrase_Type(JCas jcas, Type casType) {
    super(jcas, casType);
    casImpl.getFSClassRegistry().addGeneratorForType((TypeImpl)this.casType, getFSGenerator());

 
    casFeat_id = jcas.getRequiredFeatureDE(casType, "id", "uima.cas.Integer", featOkTst);
    casFeatCode_id  = (null == casFeat_id) ? JCas.INVALID_FEATURE_CODE : ((FeatureImpl)casFeat_id).getCode();

 
    casFeat_CCid = jcas.getRequiredFeatureDE(casType, "CCid", "uima.cas.Integer", featOkTst);
    casFeatCode_CCid  = (null == casFeat_CCid) ? JCas.INVALID_FEATURE_CODE : ((FeatureImpl)casFeat_CCid).getCode();

 
    casFeat_Mid = jcas.getRequiredFeatureDE(casType, "Mid", "uima.cas.Integer", featOkTst);
    casFeatCode_Mid  = (null == casFeat_Mid) ? JCas.INVALID_FEATURE_CODE : ((FeatureImpl)casFeat_Mid).getCode();

 
    casFeat_N2id = jcas.getRequiredFeatureDE(casType, "N2id", "uima.cas.Integer", featOkTst);
    casFeatCode_N2id  = (null == casFeat_N2id) ? JCas.INVALID_FEATURE_CODE : ((FeatureImpl)casFeat_N2id).getCode();

 
    casFeat_text = jcas.getRequiredFeatureDE(casType, "text", "uima.cas.String", featOkTst);
    casFeatCode_text  = (null == casFeat_text) ? JCas.INVALID_FEATURE_CODE : ((FeatureImpl)casFeat_text).getCode();

 
    casFeat_sentence = jcas.getRequiredFeatureDE(casType, "sentence", "uima.cas.String", featOkTst);
    casFeatCode_sentence  = (null == casFeat_sentence) ? JCas.INVALID_FEATURE_CODE : ((FeatureImpl)casFeat_sentence).getCode();

 
    casFeat_pattern = jcas.getRequiredFeatureDE(casType, "pattern", "uima.cas.String", featOkTst);
    casFeatCode_pattern  = (null == casFeat_pattern) ? JCas.INVALID_FEATURE_CODE : ((FeatureImpl)casFeat_pattern).getCode();

 
    casFeat_textBegin = jcas.getRequiredFeatureDE(casType, "textBegin", "uima.cas.Integer", featOkTst);
    casFeatCode_textBegin  = (null == casFeat_textBegin) ? JCas.INVALID_FEATURE_CODE : ((FeatureImpl)casFeat_textBegin).getCode();

 
    casFeat_textEnd = jcas.getRequiredFeatureDE(casType, "textEnd", "uima.cas.Integer", featOkTst);
    casFeatCode_textEnd  = (null == casFeat_textEnd) ? JCas.INVALID_FEATURE_CODE : ((FeatureImpl)casFeat_textEnd).getCode();

 
    casFeat_heuristics = jcas.getRequiredFeatureDE(casType, "heuristics", "uima.cas.Integer", featOkTst);
    casFeatCode_heuristics  = (null == casFeat_heuristics) ? JCas.INVALID_FEATURE_CODE : ((FeatureImpl)casFeat_heuristics).getCode();

  }
}



    