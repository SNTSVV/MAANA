package lu.svv.saa.maana.proj;


import static org.apache.uima.fit.util.JCasUtil.selectCovered;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.lang3.StringUtils;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.fit.util.JCasUtil;
import org.apache.uima.jcas.JCas;
import org.uimafit.component.JCasConsumer_ImplBase;
import de.tudarmstadt.ukp.dkpro.core.api.metadata.type.DocumentMetaData;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Sentence;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token;
import de.tudarmstadt.ukp.dkpro.core.api.syntax.type.constituent.ROOT;
import de.tudarmstadt.ukp.dkpro.core.frequency.Web1TFileAccessProvider;
import de.tudarmstadt.ukp.dkpro.core.io.penntree.PennTreeUtils;
import lu.svv.saa.maana.type.AmbiguousPhrase;
import net.sf.extjwnl.JWNLException;
import net.sf.extjwnl.data.POS;
import net.sf.extjwnl.dictionary.Dictionary;


 /**
 * The class: Domain specific heuristics calculation for PAA 
 * 
 * extends J cas consumer_ impl base
 */ 
public class DomainSpecificHeuristicsPAA extends JCasConsumer_ImplBase{
		private final static int MIN_NGRAM = 1;
		private final static int MAX_NGRAM = 5;
		private static String INPUT_PATH = "";
		static Web1TFileAccessProvider web1tProvider=null;
		
		private static final double w1 = 0.07965393312242419;
		private static final double w2 = 0.045008677145429665;
		private static final double w3 = 0.003988809218925304;
		private static final double w4 = 0.028507661551097074;
		
		private static double H2Threshold= 0.001;
		private static double H1Threshold= 0.0001;
		private static int[] decisions= {0,0,0};
		private static HashMap<String,List<AmbiguousPhrase>> ResolvedNouns= new HashMap<String,List<AmbiguousPhrase>>();
		private static List<AmbiguousPhrase> Decision1=new ArrayList<AmbiguousPhrase>();
		private static List<AmbiguousPhrase> Decision2=new ArrayList<AmbiguousPhrase>();
		private static List<AmbiguousPhrase> Decision0=new ArrayList<AmbiguousPhrase>();
		private static HashMap<AmbiguousPhrase,Integer>  ProcessedPhrases=new HashMap<AmbiguousPhrase,Integer> ();
		

		public static int id=0;
		public static ArrayList<String> PAAtoSave=new ArrayList<String>();
		public static ArrayList<String> sentencesToSave=new ArrayList<String>();
		static HashMap<String,Long> TFreq= new HashMap<String,Long>();
		static HashMap<String,Long> SFreq= new HashMap<String,Long>();
		static HashMap<String,HashMap<String,Long>> XPFreq= new HashMap<String,HashMap<String,Long>>();
		static HashMap<String,HashMap<String,Long>> XPNFreq= new HashMap<String,HashMap<String,Long>>();
		static Map<String,Integer> filelist = new HashMap<String,Integer>(){
			private static final long serialVersionUID = 4580800093158014820L;
		{
			put("Pac",1);
	    	put("EAR",2);put("GST",2);put("GDD",2);put("EDR",2);
	    	put("Ros",3);
	    	put("IEE",4);put("Non",4);put("RQM",4);
	    	put("Web",5);put("Ele",5);put("Kno",5);
	    	put("Lun",6);put("Cou",6);put("ECH",6);put("Fin",6);
	    	put("Evi",7);put("Kee",7);
	    	put("Dat",8);put("Hal",8);
	    }};
		
		private static HashMap<String,Integer>  H1=new HashMap<String,Integer> ();
		private static HashMap<String,Integer>  H2=new HashMap<String,Integer> ();
		private static HashMap<String,Integer>  H3=new HashMap<String,Integer> ();
		private static HashMap<String,Integer>  H4=new HashMap<String,Integer> ();
		
		static ArrayList<String> Stop_Words = getStopWords(readfile(Main.stopWordsPath));
		static long startTime;
		
		final static boolean UseParserDefault=false;
		static boolean UseWeightedVotes=Main.UseWeightedVotes;
		static boolean UseParser = false;
		static boolean UseBNC=Main.UseBNC;
		static boolean UseOptimalThresholds=Main.UseOptimalThresholds;
		

/** 
 *
 * Process: the main function of the class
 *
 * @param aJCas  the a J cas object
 * @throws   AnalysisEngineProcessException 
 */
		public void process(JCas aJCas) throws AnalysisEngineProcessException { 

			if(UseBNC) {
				INPUT_PATH= "corpus/BNC";
			} else 
				INPUT_PATH= Main.corpusValue;
			if(UseOptimalThresholds) {
				H1Threshold = 0.0001;
				H2Threshold = 0.001;
			} else {
				H1Threshold = 0.0;
				H2Threshold = 0.0;
			}
			
			ProcessedPhrases= new HashMap<AmbiguousPhrase,Integer> ();
			Decision0=new ArrayList<AmbiguousPhrase>();
			
			PAAtoSave=new ArrayList<String>();
			if(!utils.readHeuristics) {
				try {
					web1tProvider = prepareWeb1TFormat();
				} catch (IOException e) {
					System.out.println("Failed to prepare the corpus");
					e.printStackTrace();
					return;
				}
			}
			if(utils.readHeuristics) {
				try {
					utils.readFrequenciesPAA(INPUT_PATH+"/1gms");
				} catch (ClassNotFoundException | IOException e1) {
					e1.printStackTrace();
				}
			}
			WordNetUtils();
			//loadData();
			decisions= new int[]{0,0,0};
			startTime = System.currentTimeMillis();
			System.out.println("Calculating PAA heuristics ");
			for(AmbiguousPhrase ambiguiousPhrase: JCasUtil.select(aJCas, AmbiguousPhrase.class)) {
				if(ProcessedPhrases.containsKey(ambiguiousPhrase)) {continue;}
				try {
					String phrase=ambiguiousPhrase.getText().toLowerCase();
					if(!Main.LocalPhrases.contains(ambiguiousPhrase.getText())) continue;
					if(!Main.processedPhrases.contains(phrase)){
						//UseParser=UseParserDefault;
						preparePAA(ambiguiousPhrase);
						Main.processedPhrases.add(phrase);	
						//checkpoint();
						System.out.print(".");
					}
				}catch (Exception e) {
					e.printStackTrace();
				}
			}

			if(Decision0.size()>0)
				for(AmbiguousPhrase phrase: Decision0) {
					if(ProcessedPhrases.containsKey(phrase) && ProcessedPhrases.get(phrase)!=3) continue;
					try {
						preparePAA(phrase);
						System.out.print(".");
					} catch (Exception e) {
						e.printStackTrace();
					} 
				}
			if(utils.saveHeuristics) {
				try {
					utils.saveFrequenciesPAA("Freqs");
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			try {
				DocumentMetaData dmd = DocumentMetaData.get(aJCas);
				if(Main.choiceValue==1) {
					Main.toSave.addAll(PAAtoSave);
					System.out.println();
					save2CSV(Main.outputDir+dmd.getDocumentTitle().split("\\.")[0]+"-ambiguity.csv", Main.toSave);
				} else {
					save2CSV(Main.outputDir+dmd.getDocumentTitle().split("\\.")[0]+"-PAA.csv", PAAtoSave);
				}		
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}



/** 
 *
 * prepare PAA: selects the main tokens (VNPN) and prepares heuristics calculations
 *
 * @param phrase
 * @throws   NullPointerException
 * @throws  HttpException
 * @throws  IOException
 * @throws  InterruptedException
 * @throws  JWNLException
 */
		public static void preparePAA(AmbiguousPhrase phrase) throws NullPointerException, HttpException, IOException, InterruptedException, JWNLException{ 

			int ppId=phrase.getCCid();
			Token V=selectCovered(Token.class, phrase).get(0);
			Token N1=selectCovered(Token.class, phrase).get(phrase.getMid());
			Token P=selectCovered(Token.class, phrase).get(ppId);
			Token N2=selectCovered(Token.class, phrase).get(phrase.getN2id());
			int[] solution=solvePAA(V,N1,P,N2,phrase);
			phrase.setHeuristics(solution[1]);
			if(solution[1]!=0) {
				if(ResolvedNouns.containsKey(N2.getCoveredText())){
						List<AmbiguousPhrase> list=ResolvedNouns.get(N2.getCoveredText());
						list.add(phrase);
						ResolvedNouns.put(N2.getCoveredText(),list);
				} else {
					List<AmbiguousPhrase> list=new ArrayList<AmbiguousPhrase>();
					list.add(phrase);
					ResolvedNouns.put(N2.getCoveredText(),list);
				}
			}
		}

/** 
 *
 * Solve PAA: heuristics calculations
 *
 * @param V  the  Verb
 * @param N1  Noun1
 * @param P  the  Preposition
 * @param N2  Noun2
 * @param phrase
 * @return int[] heuristics values and decisions
 * @throws   NullPointerException
 * @throws  HttpException
 * @throws  IOException
 * @throws  InterruptedException
 * @throws  JWNLException 
 */
		public static int[] solvePAA(Token V,Token N1,Token P,Token N2,AmbiguousPhrase phrase) throws NullPointerException, HttpException, IOException, InterruptedException, JWNLException { 

			int f,decision,h1=-1,h2=-1,PD=-1,FS=-1;
			String Phrase = phrase.getText().trim(); 
			if(phrase.getHeuristics()==0) {
				f=1;
				FS =FirstSense(V,N1,P,N2,phrase);
				decision=FS;
				H3.put(Phrase, FS);
			} else {
				f=0;
				int fN=XFreq(N1);
				int fV=XFreq(V);
				h1=H1(V,N1,P,fN,fV);
				h2=H2(V,N1,P,N2,fN,fV);
				H1.put(Phrase, h1);
				H2.put(Phrase, h2);

				decision=0;
				if(h1==0) { if(h2!=0) decision=h2;} 
				else if(h2==0) { if(h1!=0) decision=h1;}
				else {if(h1==h2) decision=h1;
				else decision=0;}
				PD:if(UseParser) {
					PD = ParserDecision(Main.ppPhrases.get(phrase),selectCovered(Token.class, phrase).get(phrase.getCCid()-1).getCoveredText());
					H4.put(Phrase, PD);
					if (PD==-1) break PD;
					switch (h1+h2+PD) {
					case 1: decision=1;break;
					case 2: decision=PD;break;
					case 3: decision=h1==1&&h2==1?1:0;break;
					case 4: decision=h1==1||h2==1?1:2;break;
					case 5: decision=2;break;
					case 6: decision=2;break;
					default:decision=0;break;
					}
				}
			}	
			boolean isSecond = true;
			switch (decision) {
			case 1:
				Decision1.add(phrase);
				decisions[1]++;
				break;
			case 2:
				Decision2.add(phrase);
				decisions[2]++;
				break;
			case 0:
				if(f==0) {
					Decision0.add(phrase);
					isSecond= false;
				}
				decisions[0]++;
				break;
			}
			if(isSecond) {
				
				int[] Hs = new int[5];
				if(H1.containsKey(Phrase)) Hs[1]= H1.get(Phrase);
				if(H2.containsKey(Phrase)) Hs[2]= H2.get(Phrase);
				if(H3.containsKey(Phrase)) Hs[3]= H3.get(Phrase);
				if(H4.containsKey(Phrase)) Hs[4]= H4.get(Phrase);
				if(UseWeightedVotes) {
					decision=weightVotes(Hs[1],Hs[2],Hs[3],Hs[4]);
					toSave(phrase.getSentence(),Phrase, "PAA",decision,phrase.getPattern());
				} else {
					decision = majVotes(Hs[1],Hs[2],Hs[3],Hs[4]);
					toSave(phrase.getSentence(),Phrase, "PAA",decision,phrase.getPattern());
				}
			}
			if(f==1) {
				decisions[0]--;
				ProcessedPhrases.put(phrase, decision);
			} else {
				ProcessedPhrases.put(phrase, decision==0 ? 3 : decision);
			}
			return new int[] {f,decision,h1,h2,PD};
		}

/** 
 *
 * Majority vote
 *
 * @param H1  heuristic1
 * @param H2  heuristic2
 * @param H3  heuristic3
 * @param H4  heuristic4
 * @return int combination
 */
		public static int majVotes(int H1,int H2, int H3, int H4) { 

			double NAScore=0,VAScore=0;
			if(H1==1) NAScore+= 1; else if(H1==2) VAScore+=1;
			if(H2==1) NAScore+= 1; else if(H2==2) VAScore+=1;
			if(H3==1) NAScore+= 1; else if(H3==2) VAScore+=1;
			if(H4==1) NAScore+= 1; else if(H4==2) VAScore+=1;
			if(NAScore>VAScore) return 1;
			else if(NAScore<VAScore) return 2;
			else return 0;
		}

/** 
 *
 * Weighted vote
 *
 * @param H1  heuristic1
 * @param H2  heuristic2
 * @param H3  heuristic3
 * @param H4  heuristic4
 * @return int combination
 */
		public static int weightVotes(int H1,int H2, int H3, int H4) { 

			double NAScore=0,VAScore=0;
			if(H1==1) NAScore+= w1; else if(H1==2) VAScore+=w1;
			if(H2==1) NAScore+= w2; else if(H2==2) VAScore+=w2;
			if(H3==1) NAScore+= w3; else if(H3==2) VAScore+=w3;
			if(H4==1) NAScore+= w4; else if(H4==2) VAScore+=w4;
			if(NAScore>VAScore) return 1;
			else if(NAScore<VAScore) return 2;
			else return 0;
		}

/** 
 *
 * Parser heuristic
 *
 * @param sentence 
 * @param wordBeforePP  the word before the preposition
 * @return int parser's decision
 */
		private static int ParserDecision(Sentence sentence, String wordBeforePP) { 

			String pennTree="";
			for(ROOT root : selectCovered(ROOT.class, sentence)) {
				pennTree= PennTreeUtils.toPennTree(PennTreeUtils.convertPennTree(root));
			}
		    	String[] elements=pennTree.split(" ");
		    	int id=-1;
		    	for (int i=0; i<elements.length;i++) {
					if(elements[i].equals("(IN") && elements[i-2].startsWith(wordBeforePP)) {
						id=i;
						break;
					}
				}
		    	if(id==-1) return -1;
		    	int count=-1;
		    	for (int i=id-2; i==0;i--) {
		    		count -= StringUtils.countMatches(elements[i], ")");
		    		count += StringUtils.countMatches(elements[i], "(");
		    		if(count==0) {
		    			return 1;
		    		}
		    		if(elements[i].startsWith("(VB")) return 2;
		    	}
		    	if(elements[id-1].startsWith("(SBAR")) return 2;
		    	return 1;
		 }

/** 
 *
 * First sense heuristic
 *
 * @param v  the verb
 * @param n1  noun1
 * @param p  the preposition
 * @param n2  noun2
 * @param phrase
 * @return int decision
 * @throws   JWNLException 
 */
		public static int FirstSense(Token v, Token n1, Token p, Token n2, AmbiguousPhrase phrase) throws JWNLException { 

			if(!ResolvedNouns.containsKey(n2.getCoveredText()))
				return 0;
			String fnn1=getFileName(n1.getLemmaValue(), POS.NOUN);
			String fnv=getFileName(v.getLemmaValue(), POS.VERB);
			List<AmbiguousPhrase> list= ResolvedNouns.get(n2.getCoveredText());
			for(AmbiguousPhrase P: list) {
				int h=P.getHeuristics();
				if(h==1) {
					if(fnn1==getFileName(selectCovered(Token.class, P).get(P.getMid()).getLemmaValue(), POS.NOUN))
						return 1;
				} else if (h==2) {
					if(fnv==getFileName(selectCovered(Token.class, P).get(0).getLemmaValue(), POS.VERB))
						return 2;
				}
			}
			return 0;
		}

/** 
 *
 * Prepare web1 T format to open a corpus
 *
 * @param IOException{  the  IO exception{
 * @return Web1TFileAccessProvider
 * @throws   IOException
 */
	    private static Web1TFileAccessProvider prepareWeb1TFormat() throws IOException{ 

	            Web1TFileAccessProvider web1tProvider = new Web1TFileAccessProvider("en", new File(INPUT_PATH),
	                    MIN_NGRAM, MAX_NGRAM);
	            return web1tProvider;
	    }
		private static Dictionary dict;

/** 
 *
 * preparing WordNet utils 
 *
 */
		public static void WordNetUtils() { 

			try {
				dict = Dictionary.getDefaultResourceInstance();
			} catch (JWNLException e) {
				e.printStackTrace();
			}
		}

/** 
 *
 * Gets WordNet file name
 *
 * @param word
 * @param pos  the POS-tag
 * @return the file name
 * @throws   JWNLException 
 */
		public static String getFileName(String word,POS pos) throws JWNLException { 

			try {
				return dict.lookupIndexWord(pos, word).getSenses().get(0).getLexFileName();
			} catch (Exception e) {
				return "";
			}
			
		}

/** 
 *
 * H1: heuristic 1
 *
 * @param V  the  Verb
 * @param N  the  Noun1
 * @param P  the  Preposition
 * @param freqN  the frequency of Noun1
 * @param freqV  the frequency of the Verb
 * @return int decision
 * @throws   NullPointerException
 * @throws  HttpException
 * @throws  IOException
 * @throws  InterruptedException 
 */
		public static int H1(Token V,Token N,Token P,int freqN,int freqV) throws NullPointerException, HttpException, IOException, InterruptedException { 

			int vpf = XPFreq(V, P);
			int npf = XPFreq(N, P);
			float coocVP=(float) vpf/freqV;
			float coocNP=(float) npf/freqN;
			if(Math.max(coocVP,coocNP)<H1Threshold) return 0;
			if(coocVP>coocNP) return 2;
			if(coocVP<coocNP) return 1;
			return 0;
		}

/** 
 *
 * H2L heuristic 2
 *
 * @param V  the  Verb
 * @param N1  the noun1
 * @param P  the  Preposition
 * @param N2  the noun2
 * @param freqN  the frequency of Noun1
 * @param freqV  the frequency the Verb
 * @return int decision
 * @throws   NullPointerException
 * @throws  HttpException
 * @throws  IOException
 * @throws  InterruptedException 
 */
		private static int H2(Token V, Token N1, Token P, Token N2, int freqN, int freqV) throws NullPointerException, HttpException, IOException, InterruptedException { 

			int vpf=XPNFreq(V,P,N2);
			int npf=XPNFreq(N1,P,N2);
			float coocVPN2=(float)vpf/freqV;
			float coocNPN2=(float)npf/freqN;
			if(coocVPN2==0)
				if(coocNPN2>H2Threshold) return 1;
				else return 0;
			if(coocNPN2==0)
				if(coocVPN2>H2Threshold) return 2;
				else return 0;
			if(coocNPN2==coocVPN2) return 0;
			if(coocVPN2>coocNPN2) return 2;
			if(coocVPN2<coocNPN2) return 1;
			return 0;
		}

/** 
 *
 *  X freq: get the frequency of a given token
 *
 * @param X  the  input token
 * @return int frequency
 * @throws   NullPointerException
 * @throws  HttpException
 * @throws  IOException
 * @throws  InterruptedException 
 */
		public static int XFreq(Token X) throws NullPointerException, HttpException, IOException, InterruptedException { 

	    	return (int) getFreq(X);
		}

/** 
 *
 *  XP freq: get the co-occurrence frequency of the given token X and the preposition P
 *
 * @param X  the  input token
 * @param P  the  preposition
 * @return int frequency
 * @throws   NullPointerException
 * @throws  HttpException
 * @throws  IOException
 * @throws  InterruptedException 
 */
		public static int XPFreq(Token X, Token P) throws NullPointerException, HttpException, IOException, InterruptedException { 

			return (int) getFreq(X,P);
		}

/** 
 *
 *  XPN freq: get the co-occurrence frequency of the given token X, the preposition P, and the noun N
 *
 * @param X  the  input token
 * @param P  the  Preposition
 * @param N  the  Nnoun
 * @return int frequency
 * @throws   NullPointerException
 * @throws  HttpException
 * @throws  IOException
 * @throws  InterruptedException 
 */
		public static int XPNFreq(Token X, Token P,Token N) throws NullPointerException, HttpException, IOException, InterruptedException { 

			return (int) getFreq(X,P,N);
		}

/** 
 *
 * Remove stop words from a given string
 *
 * @param input  the input string
 * @return String without stop words
 */
		public static String removeStopWords(String input) { 

			ArrayList<String> words= new ArrayList<>();
			for(String word: input.split(" "))
				if(!Stop_Words.contains(word))
					words.add(word);
			return String.join(" ", words);
		}


/** 
 *
 * Gets the frequency of a given token
 *
 * @param word  the token
 * @return the frequency
 * @throws   IOException 
 */
	    public static long getFreq(Token token) throws IOException { 
	    	String word=token.getCoveredText();
	    	long freq=getSavedFreq(word, TFreq);
	    	if(freq>=0) return freq;
	    	freq=web1tProvider.getFrequency(word);
	    	if(!token.getLemmaValue().equals(word))
	    		freq+=web1tProvider.getFrequency(word);
	    	if(utils.saveHeuristics) {
	    		TFreq.put(word, freq);
	    	}
	    	return freq;
	    }
	    
/** 
*
* Gets the saved frequency of a given token from the frequency map
*
* @param word token
* @param FreqMap  the frequency map
* @return the saved frequency
*/
	    public static long getSavedFreq(String word, HashMap<String,Long> FreqMap) { 
	    	if(!utils.readHeuristics) return -1;
			if(FreqMap.containsKey(word))
    			return FreqMap.get(word);
	    	return 0;
	    }
/** 
*
* Gets the saved frequency of two words from the frequency map
*
* @param word1
* @param word2  
* @param FreqMap  the frequency map
* @return the saved frequency
*/
    public static long getSavedFreq(String word1, String word2, HashMap<String,HashMap<String,Long>> FreqMap) { 

    	if(!utils.readHeuristics) return -1;
		if(FreqMap.containsKey(word1))
    		if(FreqMap.get(word1).containsKey(word2))
    			return FreqMap.get(word1).get(word2);
    	if(FreqMap.containsKey(word2))
    		if(FreqMap.containsKey(word1))
    			return FreqMap.get(word2).get(word1);
    	return -1;
    }

/** 
 *
 * Gets the frequency of a pair of tokens
 *
 * @param N  token1
 * @param P  token2
 * @return the frequency
 * @throws   IOException 
 */
	    public static long getFreq(Token N,Token P) throws IOException { 
	    	long freq = 0;
	    	String p =P.getCoveredText();
	    	String n =N.getCoveredText();
	    	if(utils.readHeuristics) {
		    	freq=getSavedFreq(n, p, XPFreq);
		    	if(freq>=0) return freq;
	    	}
	    	freq = web1tProvider.getFrequency(n+" "+p);
	    	if(!N.getLemmaValue().equals(n))
    			freq+=web1tProvider.getFrequency(N.getLemmaValue()+" "+p);
	    	if(utils.saveHeuristics) {
		    	HashMap<String,Long> hm = new HashMap<String,Long>();
		    	if(XPFreq.containsKey(n)) {
		    		hm=XPFreq.get(n);
		    		hm.put(p, freq);
		    		XPFreq.put(n, hm);
		    		return freq;
		    	} 
		    	hm.put(p, freq);
	    		XPFreq.put(n,hm);	
		    }
	    	return freq;
	    }

/** 
 *
 * Gets the frequency of three tokens
 *
 * @param X  token1
 * @param P  token2
 * @param N  token3
 * @return the frequency
 * @throws   IOException 
 */
	    public static long getFreq(Token X,Token P, Token N) throws IOException { 
	    	long freq = 0;
	    	String x =X.getCoveredText();
	    	String p =P.getCoveredText();
	    	String n =N.getCoveredText();
	    	if(utils.readHeuristics) {
		    	freq=getSavedFreq(x, p+" "+n,XPNFreq);
		    	if(freq>=0) return freq;
	    	}
	    	if(X.getLemmaValue().equals(X.getCoveredText())) {
	    		if(N.getLemmaValue().equals(N.getCoveredText()))
	    			freq= web1tProvider.getFrequency(X.getCoveredText()+" "+P.getCoveredText()+" "+N.getCoveredText());
	    		else freq= web1tProvider.getFrequency(X.getCoveredText()+" "+P.getCoveredText()+" "+N.getCoveredText())
	    				+web1tProvider.getFrequency(X.getCoveredText()+" "+P.getCoveredText()+" "+N.getLemmaValue());
	    	}
	    	else if(N.getLemmaValue().equals(N.getCoveredText()))
	    		freq= web1tProvider.getFrequency(X.getCoveredText()+" "+P.getCoveredText()+" "+N.getCoveredText())
	    				+web1tProvider.getFrequency(X.getLemmaValue()+" "+P.getCoveredText()+" "+N.getCoveredText());
	    	else freq= web1tProvider.getFrequency(X.getCoveredText()+" "+P.getCoveredText()+" "+N.getCoveredText())
    				+web1tProvider.getFrequency(X.getLemmaValue()+" "+P.getCoveredText()+" "+N.getCoveredText())
    				+web1tProvider.getFrequency(X.getCoveredText()+" "+P.getCoveredText()+" "+N.getLemmaValue())
    				+web1tProvider.getFrequency(X.getLemmaValue()+" "+P.getCoveredText()+" "+N.getLemmaValue());
	    	if(utils.saveHeuristics) {
		    	HashMap<String,Long> hm = new HashMap<String,Long>();
		    	if(XPNFreq.containsKey(x)) {
		    		hm=XPNFreq.get(x);
		    		hm.put(p+" "+n, freq);
		    		XPNFreq.put(x, hm);
		    		return freq;
		    	} 
		    	hm.put(p+" "+n, freq);
	    		XPNFreq.put(x,hm);	
		    }
	    	return freq;
	    }
/** 
 *
 * Read a file from a given url
 *
 * @param url
 * @return String: the file
 */
		public static String readfile(String url){ 

			File fileDir = new File(url);
			String texte="";
			try {
				BufferedReader bf = new BufferedReader(new InputStreamReader( new FileInputStream(fileDir), "utf-8"));
				String input = bf.readLine();
				while(input!=null){
					texte = texte.concat(input);
					input = bf.readLine();
				}
				bf.close();
				return texte;
			} catch(Exception ex){System.out.println(ex.toString());}
			return texte;
		}

/** 
 *
 * Extracts the stop words from the stopwords file
 *
 * @param Words  the stopwords file
 * @return the stop words
 */
		public static ArrayList<String> getStopWords(String Words){ 

			StringTokenizer Stop_Words = new StringTokenizer(Words, ", ");
			ArrayList<String> Stop_Words2 = new ArrayList<String>();
			while(Stop_Words.hasMoreTokens()){
				Stop_Words2.add(Stop_Words.nextToken());
			}
			return Stop_Words2;
		}
/** 
 *
 * To save: preparing to output lines to save
 *
 * @param sentence  
 * @param phrase  
 * @param ambiguity_type
 * @param FD:  the Final Decision
 * @param pattern 
 */
		public static void toSave(String sentence, String phrase, String ambiguity_type, int FD, String pattern) { 

			StringBuilder sb = new StringBuilder();
	        sb.append(sentence);
	        sb.append(';');
	        int index=0;
	        index=sentence.indexOf(phrase);
	        if (index<1)
	        	index=sentence.indexOf(phrase.split(" ")[0]);
	        if(Main.useOffsets)
	        	sb.append(index);
	        else
	        	sb.append(phrase);
	        sb.append(';');
	        sb.append("PAA");
	        sb.append(';');
	        if(pattern.contains("N/A")) {
	        	if(FD==1)
	        		sb.append("2-Noun Attachment");
	        	else if(FD==2)
	        		sb.append("1-Verb Attachment");
	        	else
	        		sb.append("0-Ambiguous");
	        }
	        else 
	        	sb.append("0-Ambiguous");
	        if(Main.detailedOutput)
	        	sb.append(" -p "+pattern+" -h "+FD+ " -f "+phrase);
	        sb.append('\n');
//			        System.out.println(sb.toString());
	        if(!sentencesToSave.contains(sentence))
	        	sentencesToSave.add(sentence);
	    	PAAtoSave.add(sb.toString());
	        id++;
		}

/** 
 *
 * Save to CSV: create a csv file with the header then loops of over the prepared toSave list 
 *
 * @param filename
 * @param toSave  the toSave list
 * @throws   FileNotFoundException 
 */
		public static void save2CSV(String filename,ArrayList<String> toSave) throws FileNotFoundException { 

			PrintWriter pw = new PrintWriter(new File(filename));
	        StringBuilder sb = new StringBuilder();
	        sb.append("Sentence");
	        sb.append(';');
	        sb.append("Beginning offset");
	        sb.append(';');
	        sb.append("Ambiguity Type");
	        sb.append(';');
	        sb.append("Final Decision");
	        sb.append('\n');
	        pw.write(sb.toString());
	        for(String line: toSave)
	        	pw.write(line);
	        pw.close();
	        System.out.println(filename+" created!");
		}
}
